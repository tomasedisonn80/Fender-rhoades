#include <xcb/xcb.h>
#include <cstdio>
#include <ctime>
#include <dlfcn.h>

namespace {
xcb_connection_t* observed[16]{};
bool draining[16]{};
bool tracked(xcb_connection_t* connection) {
    for (auto* candidate : observed) { if (candidate == connection) { return true; } }
    return false;
}
double now() {
    timespec stamp{};
    clock_gettime(CLOCK_MONOTONIC, &stamp);
    return static_cast<double>(stamp.tv_sec) + static_cast<double>(stamp.tv_nsec) / 1e9;
}
template <class Function> Function original(const char* name) {
    return reinterpret_cast<Function>(dlsym(RTLD_NEXT, name));
}
}

extern "C" xcb_void_cookie_t xcb_change_window_attributes_checked(
    xcb_connection_t* connection, xcb_window_t window, uint32_t value_mask,
    const void* value_list) {
    static auto function = original<decltype(&xcb_change_window_attributes_checked)>(
        "xcb_change_window_attributes_checked");
    if (value_mask == XCB_CW_EVENT_MASK && value_list != nullptr &&
        *static_cast<const uint32_t*>(value_list) ==
            (XCB_EVENT_MASK_FOCUS_CHANGE | XCB_EVENT_MASK_STRUCTURE_NOTIFY)) {
        if (!tracked(connection)) {
            for (auto*& candidate : observed) {
                if (candidate == nullptr) { candidate = connection; break; }
            }
        }
        std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p subscribe=%u\n",
                     now(), static_cast<void*>(connection), window);
    }
    return function(connection, window, value_mask, value_list);
}

extern "C" xcb_query_tree_reply_t* xcb_query_tree_reply(
    xcb_connection_t* connection, xcb_query_tree_cookie_t cookie,
    xcb_generic_error_t** error) {
    static auto function = original<decltype(&xcb_query_tree_reply)>("xcb_query_tree_reply");
    auto* reply = function(connection, cookie, error);
    if (tracked(connection)) {
        std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p tree seq=%u root=%u parent=%u\n",
                     now(), static_cast<void*>(connection), cookie.sequence,
                     reply == nullptr ? 0U : reply->root,
                     reply == nullptr ? 0U : reply->parent);
    }
    return reply;
}

extern "C" xcb_get_input_focus_reply_t* xcb_get_input_focus_reply(
    xcb_connection_t* connection, xcb_get_input_focus_cookie_t cookie,
    xcb_generic_error_t** error) {
    static auto function = original<decltype(&xcb_get_input_focus_reply)>("xcb_get_input_focus_reply");
    auto* reply = function(connection, cookie, error);
    if (tracked(connection)) {
        std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p fence focus=%u\n",
                     now(), static_cast<void*>(connection), reply == nullptr ? 0U : reply->focus);
    }
    return reply;
}

extern "C" xcb_generic_event_t* xcb_poll_for_event(xcb_connection_t* connection) {
    static auto function = original<decltype(&xcb_poll_for_event)>("xcb_poll_for_event");
    auto* event = function(connection);
    for (unsigned index = 0; index < 16; ++index) {
        if (observed[index] == connection) {
            if (event == nullptr && draining[index]) {
                std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p DRAIN_END\n",
                             now(), static_cast<void*>(connection));
            }
            draining[index] = event != nullptr;
        }
    }
    if (tracked(connection) && event != nullptr) {
        const auto type = event->response_type & 0x7fU;
        if (type == XCB_FOCUS_IN || type == XCB_FOCUS_OUT) {
            const auto& focus = *reinterpret_cast<xcb_focus_in_event_t*>(event);
            std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p event=%s window=%u detail=%u mode=%u\n",
                         now(), static_cast<void*>(connection), type == XCB_FOCUS_IN ? "IN" : "OUT",
                         focus.event, focus.detail, focus.mode);
        } else if (type == XCB_REPARENT_NOTIFY) {
            const auto& change = *reinterpret_cast<xcb_reparent_notify_event_t*>(event);
            std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p REPARENT window=%u parent=%u\n",
                         now(), static_cast<void*>(connection), change.window, change.parent);
        } else if (type == XCB_DESTROY_NOTIFY) {
            const auto& change = *reinterpret_cast<xcb_destroy_notify_event_t*>(event);
            std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p DESTROY window=%u\n",
                         now(), static_cast<void*>(connection), change.window);
        }
    }
    return event;
}

extern "C" void xcb_disconnect(xcb_connection_t* connection) {
    static auto function = original<decltype(&xcb_disconnect)>("xcb_disconnect");
    if (tracked(connection)) {
        std::fprintf(stderr, "FOCUS_TRACE %.9f conn=%p disconnect\n",
                     now(), static_cast<void*>(connection));
        for (auto*& candidate : observed) {
            if (candidate == connection) { candidate = nullptr; }
        }
    }
    function(connection);
}

"""Summarize one untouched REAPER probe run and its native pixel captures."""
from pathlib import Path
import hashlib
import json
import sys

from PIL import Image, ImageChops

base = Path(sys.argv[1])
run = json.loads((base / "run.json").read_text())


def difference(first, second):
    a = Image.open(base / "captures" / (first + ".png")).convert("RGB")
    b = Image.open(base / "captures" / (second + ".png")).convert("RGB")
    delta = ImageChops.difference(a, b)
    red, green, blue = delta.split()
    any_channel = ImageChops.lighter(ImageChops.lighter(red, green), blue)
    return {"identical_rgb": delta.getbbox() is None,
            "difference_bbox": delta.getbbox(),
            "different_pixels": a.width * a.height - any_channel.histogram()[0],
            "total_pixels": a.width * a.height}


counts = {status: sum(check["status"] == status for check in run["checks"])
          for status in ("pass", "fail")}
result = {
    "scope": "W3-003 native REAPER UI regression; closed audio device; no direct edit callback or processor note-off observation",
    "completed": run.get("completed", False),
    "counts": counts,
    "failed_checks": [check for check in run["checks"] if check["status"] != "pass"],
    "cold_initial_focus": run.get("cold_initial_focus"),
    "cold_focus_after_press": run.get("cold_volume_focus_after_press"),
    "cold_focus_events": run.get("cold_volume_focus_events"),
    "volume_check": next(check for check in run["checks"]
                         if check["name"] == "native_volume_updates_host_parameter"),
    "keyboard_held_vs_focus_loss": difference("keyboard-held", "keyboard-focus-loss"),
    "keyboard_focus_loss_vs_idle": difference("keyboard-focus-loss", "idle-native-editor"),
    "volume_held_vs_focus_loss": difference("focus-volume-held", "focus-volume-after-loss"),
    "volume_focus_loss_vs_idle": difference("focus-volume-after-loss", "idle-native-editor"),
    "final_vs_idle": difference("final-native-editor", "idle-native-editor"),
    "module_hashes_stable": run["before_modules"] == run["after_modules"],
    "source_hashes_stable": run["before_sources"] == run["after_sources"],
    "input_sha256": {name: hashlib.sha256((base / name).read_bytes()).hexdigest()
                     for name in ("run.json", "parameters.tsv", "probe.log", "probe.lua",
                                  "probe_reaper.py", "launch-transcript.jsonl", "loaded-maps.txt")},
}
(base / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))

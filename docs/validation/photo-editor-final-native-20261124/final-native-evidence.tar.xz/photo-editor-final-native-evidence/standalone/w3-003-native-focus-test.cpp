// Retain every W2 assertion and add the actual REAPER embedding topology.
#define main w2_native_focus_regressions
#include "w2-013-native-focus-test.cpp"
#undef main

namespace {
void prepare_cold_focus(xcb_connection_t* connection, PhotoNativeFocus& observer,
                       xcb_window_t top, xcb_window_t container, xcb_window_t editor) {
    observer.reset();
    const std::uint32_t above = XCB_STACK_MODE_ABOVE;
    xcb_configure_window(connection, top, XCB_CONFIG_WINDOW_STACK_MODE, &above);
    xcb_configure_window(connection, container, XCB_CONFIG_WINDOW_STACK_MODE, &above);
    xcb_warp_pointer(connection, XCB_WINDOW_NONE, editor, 0, 0, 0, 0, 50, 50);
    focus(connection, XCB_INPUT_FOCUS_POINTER_ROOT);
    observer.attach(editor);
    check(!observer.poll(true), "cold embedded attachment has no loss");
}

void complete_cold_focus(xcb_connection_t* connection, PhotoNativeFocus& observer,
                        xcb_window_t editor, xcb_window_t proxy) {
    focus(connection, editor);
    focus(connection, proxy);
    check(!observer.poll(true), "cold explicit editor to exact host proxy preserves first gesture");
}
}

int main() {
    const int previous = w2_native_focus_regressions();
    if (previous != 0) { return previous; }
    auto* connection = xcb_connect(nullptr, nullptr);
    if (connection == nullptr || xcb_connection_has_error(connection) != 0) { return 2; }
    try {
        const auto root = xcb_setup_roots_iterator(xcb_get_setup(connection)).data->root;
        const auto top = window(connection, root);
        const auto container = window(connection, top);
        const auto editor = window(connection, container);
        const auto main_window = window(connection, root);
        const auto other_host_child = window(connection, top);
        PhotoNativeFocus observer;

        // REAPER creates its embedding container below root, then moves it
        // into the floating host after the native observer has attached.
        const auto moving_container = window(connection, root);
        const auto moving_editor = window(connection, moving_container);
        PhotoNativeFocus moving_observer;
        focus(connection, main_window);
        moving_observer.attach(moving_editor);
        (void)moving_observer.poll(true);
        xcb_reparent_window(connection, moving_container, top, 0, 0);
        synchronize(connection);
        check(moving_observer.poll(true), "initial embedding reparent cancels before topology refresh");
        moving_observer.attach(moving_editor);
        const std::uint32_t moving_above = XCB_STACK_MODE_ABOVE;
        xcb_configure_window(connection, top, XCB_CONFIG_WINDOW_STACK_MODE, &moving_above);
        xcb_configure_window(connection, moving_container, XCB_CONFIG_WINDOW_STACK_MODE, &moving_above);
        xcb_warp_pointer(connection, XCB_WINDOW_NONE, moving_editor, 0, 0, 0, 0, 50, 50);
        focus(connection, XCB_INPUT_FOCUS_POINTER_ROOT);
        (void)moving_observer.poll(true);
        focus(connection, moving_editor);
        focus(connection, top);
        check(!moving_observer.poll(true), "same native window refreshes reparented host before first cold gesture");
        xcb_destroy_window(connection, moving_container);
        synchronize(connection);
        check(moving_observer.poll(true), "destroyed embedded path cancels its active proxy");
        moving_observer.attach(moving_editor);
        moving_observer.attach(moving_editor);
        check(!moving_observer.poll(true), "destroyed native handle does not repeat loss on attachment calls");
        moving_observer.reset();

        // Attachment may precede dismissal of a host startup dialog. The
        // first editor acquisition must be recognized from its own events.
        focus(connection, main_window);
        observer.attach(editor);
        check(!observer.poll(true), "attachment while startup host window is focused has no loss");
        const std::uint32_t above = XCB_STACK_MODE_ABOVE;
        xcb_configure_window(connection, top, XCB_CONFIG_WINDOW_STACK_MODE, &above);
        xcb_configure_window(connection, container, XCB_CONFIG_WINDOW_STACK_MODE, &above);
        xcb_warp_pointer(connection, XCB_WINDOW_NONE, editor, 0, 0, 0, 0, 50, 50);
        focus(connection, XCB_INPUT_FOCUS_POINTER_ROOT);
        check(!observer.poll(true), "PointerRoot after startup host focus has no editor loss");
        focus(connection, editor);
        focus(connection, top);
        check(!observer.poll(true), "first cold gesture survives host focus established after attachment");

        prepare_cold_focus(connection, observer, top, container, editor);
        complete_cold_focus(connection, observer, editor, top);
        check(!observer.poll(true), "accepted cold handoff is consumed once");
        focus(connection, main_window);
        check(observer.poll(true), "host proxy to external main cancels without child explicit focus");
        check(!observer.poll(true), "external proxy loss is consumed once");

        prepare_cold_focus(connection, observer, top, container, editor);
        complete_cold_focus(connection, observer, editor, top);
        focus(connection, main_window);
        focus(connection, top);
        check(observer.poll(true), "host proxy out and back before polling retains loss");

        prepare_cold_focus(connection, observer, top, container, editor);
        complete_cold_focus(connection, observer, editor, top);
        focus(connection, editor);
        check(!observer.poll(true), "accepted host proxy can return to its editor");
        focus(connection, top);
        check(observer.poll(true), "ordinary editor to top ancestor departure cancels after cold handoff");

        focus(connection, editor);
        (void)observer.poll(true);
        focus(connection, container);
        check(observer.poll(true), "ordinary editor to immediate parent departure cancels");
        focus(connection, editor);
        (void)observer.poll(true);
        focus(connection, top);
        focus(connection, editor);
        check(observer.poll(true), "ordinary ancestor departure and return retains loss");
        focus(connection, root);
        focus(connection, editor);
        check(observer.poll(true), "root ancestor departure and return retains loss");

        prepare_cold_focus(connection, observer, top, container, editor);
        focus(connection, editor);
        check(!observer.poll(true), "synchronized cold editor acquisition has no loss");
        focus(connection, top);
        check(observer.poll(true), "later ordinary ancestor departure is not a cold negotiation");

        prepare_cold_focus(connection, observer, top, container, editor);
        focus(connection, editor);
        focus(connection, root);
        focus(connection, top);
        check(observer.poll(true), "cold departure past hosting top then return is never waived");

        prepare_cold_focus(connection, observer, top, container, editor);
        focus(connection, editor);
        focus(connection, main_window);
        focus(connection, editor);
        focus(connection, top);
        check(observer.poll(true), "cold external out and back before host handoff retains loss");

        prepare_cold_focus(connection, observer, top, container, editor);
        complete_cold_focus(connection, observer, editor, top);
        focus(connection, other_host_child);
        check(observer.poll(true), "proxy transfer to another host child cancels");

        prepare_cold_focus(connection, observer, top, container, editor);
        complete_cold_focus(connection, observer, editor, container);
        focus(connection, main_window);
        focus(connection, container);
        check(observer.poll(true), "immediate-parent proxy out and back retains loss");

        prepare_cold_focus(connection, observer, top, container, editor);
        focus(connection, editor);
        check(!observer.poll(false), "asynchronous cold acquisition poll has no loss");
        focus(connection, top);
        check(!observer.poll(true), "cold handoff can finish after an asynchronous poll");

        const auto descendant = window(connection, editor);
        focus(connection, descendant);
        check(!observer.poll(true), "host proxy may return to an editor descendant");
        focus(connection, main_window);
        focus(connection, descendant);
        check(observer.poll(true), "editor descendant external out and back remains loss");

        prepare_cold_focus(connection, observer, top, container, editor);
        complete_cold_focus(connection, observer, editor, top);
        xcb_reparent_window(connection, container, main_window, 0, 0);
        synchronize(connection);
        check(observer.poll(true), "reparenting cached embedding path cancels and invalidates proxy");
        observer.reset();
        xcb_disconnect(connection);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << std::endl;
        xcb_disconnect(connection);
        return 1;
    }
}

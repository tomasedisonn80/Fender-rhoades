local base = '/home/agent/rhodes-7a7c13ab7da3/w3-003-reaper-run03/'
local log = assert(io.open(base .. 'probe.log', 'w'))
local samples = assert(io.open(base .. 'parameters.tsv', 'w'))
local function emit(s) log:write(s .. '\n'); log:flush() end
local function writefile(path, value)
  local f = assert(io.open(base .. path, 'w')); f:write(value); f:close()
end
emit('app_version=' .. reaper.GetAppVersion())
emit('os=' .. reaper.GetOS())
emit('resource_path=' .. reaper.GetResourcePath())
emit('ini=' .. reaper.get_ini_file())
local selected = nil
for i = 0, 10000 do
  local ok, name, ident = reaper.EnumInstalledFX(i)
  if not ok then break end
  if name:lower():find('rhodes', 1, true) then
    emit('discovered=' .. name .. '\t' .. ident)
  end
  if name:find('Rhodes Research Filtered', 1, true) then selected = name end
end
assert(selected, 'Filtered instrument not discovered')
reaper.InsertTrackAtIndex(0, true)
local tr = reaper.GetTrack(0, 0)
local fx = reaper.TrackFX_AddByName(tr, selected, false, -1)
assert(fx >= 0, 'Filtered instrument insertion failed')
local ok, loaded_name = reaper.TrackFX_GetFXName(tr, fx, '')
emit('loaded=' .. tostring(ok) .. '\t' .. loaded_name .. '\tfx_index=' .. fx)
emit('num_params=' .. reaper.TrackFX_GetNumParams(tr, fx))
samples:write('label\tseconds\tindex\tname\tident\tnormalized\tformatted\n')
local function sample(label)
  for i = 0, reaper.TrackFX_GetNumParams(tr, fx) - 1 do
    local name_ok, name = reaper.TrackFX_GetParamName(tr, fx, i)
    local ident_ok, ident = reaper.TrackFX_GetParamIdent(tr, fx, i)
    local value = reaper.TrackFX_GetParamNormalized(tr, fx, i)
    local format_ok, formatted = reaper.TrackFX_GetFormattedParamValue(tr, fx, i)
    samples:write(string.format('%s\t%.9f\t%d\t%s\t%s\t%.17g\t%s\n',
      label, reaper.time_precise(), i, name_ok and name or '<name unavailable>',
      ident_ok and ident or '<ident unavailable>', value,
      format_ok and formatted or '<format unavailable>'))
  end
  samples:flush()
  emit('sample=' .. label)
end
reaper.TrackFX_Show(tr, fx, 3)
reaper.TrackList_AdjustWindows(false)
reaper.UpdateArrange()
emit('floating_handle=' .. tostring(reaper.TrackFX_GetFloatingWindow(tr, fx)))
sample('startup')
writefile('ready', 'ready')
local deadline = reaper.time_precise() + 180
local last_command = ''
local function tick()
  local f = io.open(base .. 'command', 'r')
  local command = ''
  if f then command = f:read('*a'); f:close() end
  if command ~= '' and command ~= last_command then
    last_command = command
    sample(command)
    writefile('ack', command)
    if command == 'done' then
      emit('complete=true'); samples:close(); log:close(); return
    end
  end
  if reaper.time_precise() > deadline then
    emit('timeout=true'); samples:close(); log:close(); return
  end
  reaper.defer(tick)
end
reaper.defer(tick)

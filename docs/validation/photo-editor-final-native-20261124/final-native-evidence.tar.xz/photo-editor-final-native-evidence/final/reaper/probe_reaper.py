from pathlib import Path
import csv
import hashlib
import json
import math
import os
import subprocess
import sys
import time
import traceback

BASE = Path('/home/agent/rhodes-7a7c13ab7da3/w3-003-reaper-run03')
ROOT = BASE.parent
REPO = Path('/workspace/scratch/7a7c13ab7da3/Fender-rhoades')
sys.path.insert(0, str(ROOT / 'python-tools'))
from Xlib import X, XK, display
from Xlib.ext import xtest
from PIL import Image, ImageChops

HOST = ROOT / 'w2-008/reaper_linux_x86_64/REAPER/reaper'
MODULE_ROOT = ROOT / 'build-editor/VST3/Release'
SOURCES = ['plugins/vst3/photo_editor.cpp', 'plugins/vst3/photo_editor.hpp',
           'plugins/vst3/photo_geometry.hpp', 'plugins/vst3/controller.cpp',
           'plugins/vst3/controller.hpp', 'include/rhodes/editor_audition.hpp',
           'plugins/vst3/photo_native_focus.hpp', 'plugins/vst3/photo_native_focus.cpp']

def file_record(path):
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns}

def hashes():
    return {str(p): file_record(p)
            for p in MODULE_ROOT.glob('*.vst3/Contents/x86_64-linux/*.so')}

def source_hashes():
    return {p: file_record(REPO / p) for p in SOURCES}

class Probe:
    def __init__(self):
        self.connection = display.Display()
        self.root = self.connection.screen().root
        self.start = time.monotonic()
        self.record = {'command': [str(HOST), '-cfgfile', str(BASE / 'config/reaper.ini'),
                      '-newinst', '-nosplash', '-new', '-splashlog', str(BASE / 'splash.log'),
                      str(BASE / 'probe.lua')], 'home': os.environ.get('HOME'),
                      'host': file_record(HOST), 'before_modules': hashes(),
                      'before_sources': source_hashes(), 'actions': [], 'captures': {},
                      'x11_focus_events': [], 'checks': []}
        self.proc = self.view = self.top = self.main = None

    def elapsed(self): return round(time.monotonic() - self.start, 6)

    def action(self, name, **details):
        self.record['actions'].append({'name': name, 'elapsed': self.elapsed(), **details})

    def drain(self):
        while self.connection.pending_events():
            e = self.connection.next_event()
            if e.type in (X.FocusIn, X.FocusOut):
                self.record['x11_focus_events'].append({'kind': 'FocusIn' if e.type == X.FocusIn else 'FocusOut',
                  'window_id': e.window.id, 'mode': e.mode, 'detail': e.detail, 'elapsed': self.elapsed()})

    def pause(self, seconds=0.15):
        self.connection.sync(); time.sleep(seconds); self.drain()
        if self.proc and self.proc.poll() is not None:
            raise RuntimeError('REAPER exited early: ' + str(self.proc.returncode))

    def tree(self):
        result = []
        def walk(w, parent=None, depth=0):
            try:
                g, a = w.get_geometry(), w.get_attributes()
                atom = self.connection.intern_atom('_XEMBED_INFO')
                prop = w.get_full_property(atom, X.AnyPropertyType)
                result.append({'id': w.id, 'parent': parent, 'depth': depth, 'name': w.get_wm_name(),
                  'x': g.x, 'y': g.y, 'width': g.width, 'height': g.height,
                  'mapped': a.map_state == X.IsViewable,
                  'xembed_info': list(prop.value) if prop else None})
                for child in w.query_tree().children: walk(child, w.id, depth + 1)
            except Exception as e: result.append({'id': w.id, 'error': str(e)})
        walk(self.root)
        return result

    def key(self, name):
        code = self.connection.keysym_to_keycode(XK.string_to_keysym(name))
        xtest.fake_input(self.connection, X.KeyPress, detail=code)
        xtest.fake_input(self.connection, X.KeyRelease, detail=code)
        self.pause()

    def root_pointer(self, x, y):
        xtest.fake_input(self.connection, X.MotionNotify, x=x, y=y)
        self.pause(0.07)

    def pointer(self, point):
        g = self.view.get_geometry()
        origin = self.root.translate_coords(self.view, 0, 0)
        scale = min(g.width / 1536, g.height / 1152)
        x = round(origin.x + (g.width - 1536 * scale) / 2 + point[0] * scale)
        y = round(origin.y + (g.height - 1152 * scale) / 2 + point[1] * scale)
        self.root_pointer(x, y)

    def button(self, down):
        xtest.fake_input(self.connection, X.ButtonPress if down else X.ButtonRelease, detail=1)
        self.pause(0.1)

    def focus(self, window, reason):
        self.action('set_native_input_focus', window_id=window.id, reason=reason)
        window.set_input_focus(X.RevertToParent, X.CurrentTime)
        self.pause(0.25)
        actual = self.connection.get_input_focus().focus
        self.action('observed_native_input_focus', window_id=getattr(actual, 'id', actual))

    def capture(self, name, window=None):
        w = window or self.view
        g = w.get_geometry()
        pixels = w.get_image(0, 0, g.width, g.height, X.ZPixmap, 0xffffffff)
        img = Image.frombytes('RGB', (g.width, g.height), pixels.data, 'raw', 'BGRX')
        path = BASE / 'captures' / (name + '.png'); img.save(path)
        self.record['captures'][name] = {'path': str(path), **file_record(path),
            'width': g.width, 'height': g.height, 'rgb_sha256': hashlib.sha256(img.tobytes()).hexdigest(),
            'elapsed': self.elapsed()}
        return img

    def sample(self, label):
        temp = BASE / 'command.tmp'; temp.write_text(label); temp.replace(BASE / 'command')
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            self.pause(0.04)
            if (BASE / 'ack').exists() and (BASE / 'ack').read_text() == label:
                with (BASE / 'parameters.tsv').open() as f:
                    rows = [r for r in csv.DictReader(f, delimiter='\t') if r['label'] == label]
                self.action('host_parameter_snapshot', label=label)
                return {int(r['index']): r for r in rows}
        raise RuntimeError('ReaScript snapshot timeout: ' + label)

    def check(self, name, passed, **details):
        item = {'name': name, 'status': 'pass' if passed else 'fail', **details}
        self.record['checks'].append(item); print(json.dumps(item), flush=True)

    def launch(self):
        for name in ('ready', 'ack', 'command', 'parameters.tsv', 'probe.log'):
            (BASE / name).unlink(missing_ok=True)
        self.output = (BASE / 'reaper-output.log').open('w')
        self.proc = subprocess.Popen(self.record['command'], stdout=self.output, stderr=subprocess.STDOUT)
        self.record['pid'] = self.proc.pid
        deadline = time.monotonic() + 35
        dismissed = set()
        dismissal_attempts = {}
        while time.monotonic() < deadline:
            self.pause(0.2)
            rows = self.tree()
            about_open = any(r.get('mapped') and (r.get('name') or '').startswith('About REAPER') for r in rows)
            for r in rows:
                name = r.get('name') or ''
                if not r.get('mapped') or r['id'] in dismissed: continue
                if (name == 'Error opening devices' and not about_open) or (name.startswith('About REAPER') and self.elapsed() > 10):
                    attempt = dismissal_attempts.get(r['id'], 0) + 1
                    dismissal_attempts[r['id']] = attempt
                    self.capture('startup-dialog-' + str(r['id']) + '-attempt-' + str(attempt), self.root)
                    w = self.connection.create_resource_object('window', r['id'])
                    self.focus(w, 'Dismiss startup dialog using Escape')
                    self.key('Escape')
                    still_mapped = any(item['id'] == r['id'] and item.get('mapped') for item in self.tree())
                    if not still_mapped:
                        dismissed.add(r['id'])
                    self.action('startup_dialog_escape', title=name, attempt=attempt, confirmed_unmapped=not still_mapped)
                    break
            tops = [r for r in rows if r.get('mapped') and (r.get('name') or '').startswith('VST3i: Rhodes Research Filtered')]
            mains = [r for r in rows if r.get('mapped') and ' - REAPER v7.86' in (r.get('name') or '')]
            dialogs = [r for r in rows if r.get('mapped') and ((r.get('name') or '').startswith('About REAPER') or r.get('name') == 'Error opening devices')]
            if tops and mains and (BASE / 'ready').exists() and not dialogs:
                candidates = [r for r in rows if r.get('mapped') and r.get('depth') == 3
                              and r.get('width') == 1024 and r.get('height') == 768]
                if len(candidates) != 1: raise RuntimeError('Ambiguous native editor child')
                self.top = self.connection.create_resource_object('window', tops[0]['id'])
                self.main = self.connection.create_resource_object('window', mains[0]['id'])
                self.view = self.connection.create_resource_object('window', candidates[0]['id'])
                self.main.configure(x=1100, y=20)
                self.top.configure(x=20, y=20, stack_mode=X.Above)
                for w in (self.top, self.view, self.main): w.change_attributes(event_mask=X.FocusChangeMask)
                self.root_pointer(1250, 870); self.pause(0.6)
                self.record['window_ids'] = {'view': self.view.id, 'top': self.top.id, 'main': self.main.id}
                (BASE / 'loaded-maps.txt').write_text(Path(f'/proc/{self.proc.pid}/maps').read_text())
                self.record['attached_window_tree'] = self.tree()
                self.action('set_native_pointerroot_focus', reason='Cold first control gesture starts with PointerRoot focus')
                self.connection.set_input_focus(X.PointerRoot, X.RevertToPointerRoot, X.CurrentTime)
                self.pause(0.25)
                actual = self.connection.get_input_focus().focus
                self.record['cold_initial_focus'] = getattr(actual, 'id', actual)
                self.action('observed_cold_initial_focus', window_id=self.record['cold_initial_focus'])
                return
        self.record['startup_window_tree'] = self.tree()
        raise RuntimeError('Startup did not complete within 35 seconds')

    def run(self):
        self.launch()
        idle = self.capture('idle-native-editor')
        self.capture('reaper-context', self.root)
        baseline = self.sample('baseline')
        expected = {0: ('Monitoring Gain', '0:0'), 1: ('Sustain', '1:1'),
                    19: ('Bass', '19:3'), 20: ('Treble', '20:4'), 21: ('Intensity', '21:5'),
                    22: ('Speed', '22:6'), 23: ('Vibrato', '23:7')}
        self.record['baseline_parameters'] = baseline
        for idx, (name, ident) in expected.items():
            row = baseline.get(idx, {})
            self.check('parameter_identity_' + str(idx), row.get('name') == name and row.get('ident') == ident,
                       index=idx, expected_name=name, expected_ident=ident, observed=row)
        controls = [('volume', 0, (319,458), (319,422), 0.2),
                    ('pedal', 1, (776,932), None, 1.0),
                    ('bass', 19, (422,479), (452,479), 30/103),
                    ('treble', 20, (422,449), (452,449), 30/103),
                    ('intensity', 21, (519,458), (519,422), 0.2),
                    ('speed', 22, (603,458), (603,422), 0.2),
                    ('vibrato', 23, (560,465), None, 1.0)]
        for name, idx, begin, end, delta in controls:
            self.pause(0.6)
            before = self.sample(name + '-before')
            self.action('native_control_input', control=name, parameter_index=idx,
                        source_begin=begin, source_end=end, input='XTEST native pointer')
            if name == 'volume':
                actual = self.connection.get_input_focus().focus
                self.check('cold_first_volume_starts_from_pointerroot',
                           getattr(actual, 'id', actual) == X.PointerRoot,
                           observed_focus=getattr(actual, 'id', actual), expected_focus=X.PointerRoot)
                cold_event_start = len(self.record['x11_focus_events'])
            self.pointer(begin); self.button(True)
            if name == 'volume':
                actual = self.connection.get_input_focus().focus
                self.record['cold_volume_focus_after_press'] = getattr(actual, 'id', actual)
                self.record['cold_volume_focus_events'] = self.record['x11_focus_events'][cold_event_start:]
            if end:
                for step in range(1, 4):
                    self.pointer((begin[0]+(end[0]-begin[0])*step/3, begin[1]+(end[1]-begin[1])*step/3))
            held = self.sample(name + '-held')
            self.capture(name + '-feedback')
            self.button(False)
            after = self.sample(name + '-after')
            expected_value = min(1, float(before[idx]['normalized']) + delta)
            observed = float(after[idx]['normalized'])
            changed = [i for i in before if not math.isclose(float(before[i]['normalized']),
                       float(after[i]['normalized']), abs_tol=1e-8)]
            self.check('native_' + name + '_updates_host_parameter',
                       math.isclose(observed, expected_value, abs_tol=2e-5) and changed == [idx],
                       index=idx, before=float(before[idx]['normalized']), held=float(held[idx]['normalized']),
                       after=observed, expected=expected_value, changed_indices=changed,
                       formatted=after[idx]['formatted'])
        self.pause(0.6)
        self.pointer((319,458)); self.button(True); self.pointer((319,440))
        before_loss = self.sample('focus-volume-before-loss')
        self.capture('focus-volume-held')
        event_start = len(self.record['x11_focus_events'])
        self.focus(self.main, 'Move to actual REAPER main window while Volume button remains held')
        after_loss_image = self.capture('focus-volume-after-loss')
        after_loss = self.sample('focus-volume-after-loss')
        self.pointer((319,422))
        after_motion = self.sample('focus-volume-after-held-motion')
        self.capture('focus-volume-after-held-motion')
        volume_events = self.record['x11_focus_events'][event_start:]
        self.record['volume_focus_events'] = volume_events
        self.check('native_focusout_delivered_during_volume_hold',
                   any(e['kind']=='FocusOut' and e['window_id']==self.view.id for e in volume_events),
                   events=volume_events)
        self.check('volume_stops_changing_after_focusout_before_release',
                   float(before_loss[0]['normalized']) == float(after_loss[0]['normalized']) == float(after_motion[0]['normalized']),
                   before_loss=float(before_loss[0]['normalized']), after_loss=float(after_loss[0]['normalized']),
                   after_held_motion=float(after_motion[0]['normalized']), direct_endEdit_observed=False)
        self.check('volume_focus_loss_clears_feedback', ImageChops.difference(idle, after_loss_image).getbbox() is None)
        self.button(False); self.root_pointer(1250,870); self.pause(0.6)
        self.focus(self.view, 'Prepare separate held-key focus probe')
        self.pointer((716,603)); self.button(True)
        held_key = self.capture('keyboard-held')
        self.sample('keyboard-held')
        event_start = len(self.record['x11_focus_events'])
        self.focus(self.main, 'Move to actual REAPER main window while photographed key button remains held')
        lost_key = self.capture('keyboard-focus-loss')
        key_events = self.record['x11_focus_events'][event_start:]
        self.record['keyboard_focus_events'] = key_events
        self.check('keyboard_visual_hold_was_visible', ImageChops.difference(idle,held_key).getbbox() is not None)
        self.check('native_focusout_delivered_during_keyboard_hold',
                   any(e['kind']=='FocusOut' and e['window_id']==self.view.id for e in key_events), events=key_events)
        self.check('keyboard_focusout_clears_visual_hold', ImageChops.difference(idle,lost_key).getbbox() is None,
                   scope='UI only; audio device closed; no processor queue/audio observation')
        self.button(False); self.root_pointer(1250,870)
        self.capture('final-native-editor')
        self.sample('done')
        self.record['final_window_tree'] = self.tree()
        self.record['completed'] = True

    def finish(self):
        self.record['after_modules'] = hashes(); self.record['after_sources'] = source_hashes()
        self.record['module_hashes_stable'] = self.record['before_modules'] == self.record['after_modules']
        self.record['exit_before_cleanup'] = self.proc.poll() if self.proc else None
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try: self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired: self.proc.kill(); self.proc.wait()
        self.record['exit_after_cleanup'] = self.proc.returncode if self.proc else None
        (BASE / 'run.json').write_text(json.dumps(self.record, indent=2))

if __name__ == '__main__':
    BASE.mkdir(exist_ok=True); (BASE / 'captures').mkdir(exist_ok=True)
    (BASE / 'config').mkdir(exist_ok=True)
    config = BASE / 'config/reaper.ini'
    if not config.exists(): config.write_text('[reaper]\nvstpath=' + str(MODULE_ROOT) + '\nvstpath64=' + str(MODULE_ROOT) + '\n')
    probe = Probe()
    try: probe.run()
    except Exception:
        probe.record['error'] = traceback.format_exc(); print(probe.record['error'], flush=True)
    finally: probe.finish()
    raise SystemExit(0 if probe.record.get('completed') else 1)

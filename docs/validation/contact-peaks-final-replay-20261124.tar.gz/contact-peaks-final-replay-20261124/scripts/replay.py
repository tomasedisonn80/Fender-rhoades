#!/usr/bin/env python3
"""Bounded replay of four immutable native inputs; no producer/test execution."""
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import time
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/d6370337c6a4/Fender-rhoades')
SCRATCH = ROOT.parent
ARCHIVE = ROOT / 'docs/validation/contact-peaks-native-20261124.tar.gz'
PRIOR = ROOT / 'docs/validation/contact-peaks-native-20261124.json'
TEST_LOG = SCRATCH / 'contact-wave2-focused-final.log'
TEST_META = SCRATCH / 'contact-wave2-focused-final.json'
FINAL_JSON = ROOT / 'docs/validation/contact-peaks-final-replay-20261124.json'
FINAL_TAR = ROOT / 'docs/validation/contact-peaks-final-replay-20261124.tar.gz'
FIXTURES = ('conservative_impact', 'damped_impact', 'forced_clamp', 'preload_equilibrium')
PREFIX = 'contact-peaks-native-20261124/'
FINAL_PREFIX = 'contact-peaks-final-replay-20261124'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def identity(path):
    assert stat.S_ISREG(path.lstat().st_mode), str(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def utc():
    return datetime.now(timezone.utc).isoformat()

def write_bytes(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)

def write_json(path, record):
    write_bytes(path, (json.dumps(record, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())

def safe_name(name):
    p = PurePosixPath(name)
    return not p.is_absolute() and all(part not in ('..', '.', '') for part in name.split('/')) and '\\' not in name

def differences(old, new, prefix=''):
    if type(old) is not type(new):
        return [{'path': prefix, 'before': old, 'after': new}]
    if isinstance(old, dict):
        out = []
        for key in sorted(old.keys() | new.keys()):
            p = prefix + '/' + key
            if key not in old:
                out.append({'path': p, 'added': new[key]})
            elif key not in new:
                out.append({'path': p, 'removed': old[key]})
            else:
                out.extend(differences(old[key], new[key], p))
        return out
    if isinstance(old, list):
        if len(old) != len(new):
            return [{'path': prefix, 'before': old, 'after': new}]
        return [item for i, (a, b) in enumerate(zip(old, new)) for item in differences(a, b, prefix + '/' + str(i))]
    return [] if old == new else [{'path': prefix, 'before': old, 'after': new}]

def comparison_summary(comp):
    base = {key: comp.get(key) for key in ('fixture', 'candidate_sha256', 'availability', 'validity', 'exit_code', 'phy002_acceptance')}
    base['peaks'] = {}
    for name, peak in comp['peaks'].items():
        ref = peak['reference']
        base['peaks'][name] = {
            **{key: peak.get(key) for key in ('candidate', 'value_status', 'time_status', 'observation_consistency_status', 'time_comparison_required', 'coverage', 'exit_code')},
            'reference_kind': ref['kind'], 'reference_value_interval': ref['value_interval'],
            'reference_value_status': ref['value_status'],
            'reference_time_intervals_s': ref['maximizer_intervals_s'],
            'reference_time_status': ref['time_status']}
    return base

assert not FINAL_JSON.exists() and not FINAL_TAR.exists()
started = utc()
prior_raw = PRIOR.read_bytes()
prior = json.loads(prior_raw)
archive_identity_before = identity(ARCHIVE)
assert archive_identity_before['sha256'] == prior['archive']['sha256']
assert archive_identity_before['bytes'] == prior['archive']['bytes']
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    members = archive.getmembers()
    assert len({m.name for m in members}) == len(members)
    assert len(members) == prior['archive']['files']
    assert all(safe_name(m.name) and m.name.startswith(PREFIX) and m.isfile() for m in members)
    assert sum(m.size for m in members) == prior['archive']['uncompressed_file_bytes']
    assert sum(m.size for m in members) < 32 * 1024 * 1024
    data = {m.name[len(PREFIX):]: archive.extractfile(m).read() for m in members}
artifact_manifest = json.loads(data['artifact-manifest.json'])
assert artifact_manifest['archive_root'] == PREFIX.rstrip('/')
indexed = {item['path']: item for item in artifact_manifest['files']}
assert len(indexed) == len(artifact_manifest['files'])
assert set(data) == set(indexed) | {'artifact-manifest.json'}
for name, expected in indexed.items():
    assert len(data[name]) == expected['bytes'] and sha(data[name]) == expected['sha256'], name

test_meta_raw, test_log_raw = TEST_META.read_bytes(), TEST_LOG.read_bytes()
test_meta = json.loads(test_meta_raw)
assert sha(test_log_raw) == test_meta['log_sha256']
assert test_meta['unchanged'] and test_meta['source_sha256_before'] == test_meta['source_sha256_after']
assert test_meta['exit_code'] == 0 and b'Ran 74 tests in 2.966s\n\nOK\n' in test_log_raw
source_names = sorted(set(prior['source_sha256_before']) | set(test_meta['source_sha256_before']))
source_before = {name: sha((ROOT / name).read_bytes()) for name in source_names}
recorded_test_source_differences = {name: {'recorded': digest, 'current': source_before[name]}
                                   for name, digest in test_meta['source_sha256_after'].items()
                                   if source_before[name] != digest}
allowed_later_test_revisions = {'tests/python/test_contact_peak_backend_boundaries.py',
                                'tests/python/test_contact_peak_portability.py'}
assert set(recorded_test_source_differences) <= allowed_later_test_revisions
stage = Path(tempfile.mkdtemp(prefix='contact-peaks-final-replay-20261124-', dir=SCRATCH))
write_bytes(stage / 'scripts/replay.py', Path(__file__).read_bytes())
write_bytes(stage / 'prior-evidence/contact-peaks-native-20261124.json', prior_raw)
write_bytes(stage / 'prior-evidence/artifact-manifest.json', data['artifact-manifest.json'])
write_bytes(stage / 'focused-tests/contact-wave2-focused-final.log', test_log_raw)
write_bytes(stage / 'focused-tests/contact-wave2-focused-final.json', test_meta_raw)
for name in source_names:
    write_bytes(stage / 'source_snapshot' / name, (ROOT / name).read_bytes())
inputs = []
for fixture in FIXTURES:
    member = f'native/{fixture}/stdout.json'
    invocation = json.loads(data[f'native/{fixture}/invocation.json'])
    raw = data[member]
    assert sha(raw) == invocation['stdout_sha256'] and len(raw) == invocation['stdout_bytes']
    assert invocation['returncode'] == 0 and invocation['native_result']['fixture'] == fixture
    path = stage / 'inputs' / (fixture + '.json')
    write_bytes(path, raw)
    write_bytes(stage / 'prior-evidence' / f'{fixture}-native-invocation.json', data[f'native/{fixture}/invocation.json'])
    inputs.append({'fixture': fixture, 'original_archive_member': PREFIX + member,
                   'bytes': len(raw), 'sha256': sha(raw), 'replay_input': str(path),
                   'original_invocation_stdout_identity_matches': True,
                   'original_manifest_identity_matches': True})

binary = ROOT / 'build/vst3/rhodes_contact_reference'
binary_before = identity(binary)
python = test_meta['argv'][0]
invocations = []
for name, fixtures, timing in (('all_four_default', FIXTURES, False), ('damped_with_time', ('damped_impact',), True)):
    outbase = stage / 'cli' / name
    outbase.mkdir(parents=True)
    output = outbase / 'evidence'
    assert not output.exists()
    argv = [python, str(ROOT / 'tools/validate_contact_peaks.py')]
    for fixture in fixtures:
        argv += ['--candidate', str(stage / 'inputs' / (fixture + '.json'))]
    argv += ['--output', str(output), '--producer-binary', str(binary)]
    if timing:
        argv.append('--with-damped-time')
    began, tick = utc(), time.perf_counter()
    proc = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=40, check=False)
    elapsed = time.perf_counter() - tick
    write_bytes(outbase / 'stdout.txt', proc.stdout)
    write_bytes(outbase / 'stderr.txt', proc.stderr)
    manifest = json.loads((output / 'manifest.json').read_bytes())
    summaries = []
    comparisons = []
    prior_prefix = f'cli-audited/{name}/evidence/'
    for case in manifest['cases']:
        compfile = case['comparison_file']
        comp = json.loads((output / compfile).read_bytes())
        old_comp = json.loads(data[prior_prefix + compfile])
        old_ref = json.loads(data[prior_prefix + f'reference-{case["fixture"]}.json'])
        new_ref = json.loads((output / f'reference-{case["fixture"]}.json').read_bytes())
        original = next(item for item in inputs if item['fixture'] == case['fixture'])
        raw_identity = identity(output / case['raw_file'])
        assert raw_identity['sha256'] == original['sha256'] == case['raw_sha256'] == case['retained_sha256']
        assert raw_identity['bytes'] == original['bytes'] == case['retained_bytes'] == case['bounded_input_bytes']
        assert case['raw_complete']
        old_summary, summary = comparison_summary(old_comp), comparison_summary(comp)
        summary.update(raw_sha256=raw_identity['sha256'], raw_bytes=raw_identity['bytes'], retained_identity_matches=True)
        summaries.append(summary)
        comparison_diff = differences(old_comp, comp)
        reference_diff = differences(old_ref, new_ref)
        comparisons.append({'fixture': case['fixture'], 'same_reference_and_value_outcomes': old_summary == comparison_summary(comp),
                            'reference_differences': reference_diff, 'comparison_differences': comparison_diff})
        for filename in (compfile, f'reference-{case["fixture"]}.json'):
            write_bytes(stage / 'prior-evidence' / name / filename, data[prior_prefix + filename])
    old_manifest = json.loads(data[prior_prefix + 'manifest.json'])
    write_bytes(stage / 'prior-evidence' / name / 'manifest.json', data[prior_prefix + 'manifest.json'])
    record = {'id': name, 'argv': argv, 'cwd': str(ROOT), 'started_utc': began, 'ended_utc': utc(),
              'elapsed_s': elapsed, 'returncode': proc.returncode, 'timeout_s': 40, 'timed_out': False,
              'stdout': {'file': str((outbase / 'stdout.txt').relative_to(stage)), 'bytes': len(proc.stdout), 'sha256': sha(proc.stdout)},
              'stderr': {'file': str((outbase / 'stderr.txt').relative_to(stage)), 'bytes': len(proc.stderr), 'sha256': sha(proc.stderr)},
              'manifest_file': str((output / 'manifest.json').relative_to(stage)),
              'manifest_sha256': sha((output / 'manifest.json').read_bytes()),
              'manifest_status': manifest['status'], 'manifest_exit_code': manifest['exit_code'],
              'internal_sources_unchanged': manifest['source_unchanged'],
              'internal_source_sha256_before': manifest['source_sha256_before'],
              'internal_source_sha256_after': manifest['source_sha256_after'],
              'versions': manifest['versions'], 'declared_producer': manifest['declared_producer'],
              'cases': summaries, 'prior_comparison': comparisons,
              'manifest_added_fields': sorted(set(manifest) - set(old_manifest)),
              'case_added_fields': sorted(set(manifest['cases'][0]) - set(old_manifest['cases'][0])),
              'phy002_acceptance': manifest['phy002_acceptance']}
    write_json(outbase / 'invocation.json', record)
    invocations.append(record)

source_after = {name: sha((ROOT / name).read_bytes()) for name in source_names}
archive_identity_after = identity(ARCHIVE)
binary_after = identity(binary)
assert source_before == source_after
assert archive_identity_before == archive_identity_after
assert binary_before == binary_after
assert identity(PRIOR)['sha256'] == sha(prior_raw)
assert identity(TEST_LOG)['sha256'] == sha(test_log_raw)
assert identity(TEST_META)['sha256'] == sha(test_meta_raw)
assert all(inv['internal_sources_unchanged'] for inv in invocations)
assert invocations[0]['returncode'] == 0
scipy_available = invocations[1]['versions']['scipy'] != 'not_available'
assert invocations[1]['returncode'] == (0 if scipy_available else 2)
assert all(case['same_reference_and_value_outcomes'] for inv in invocations for case in inv['prior_comparison'])

summary = {
    'schema_version': 1, 'assignment': '20261124-w2-39-current-replay',
    'started_utc': started, 'ended_utc': utc(), 'scope': 'Current-source replay of four exact retained native fixtures and requested damped timing; no trajectory regeneration or test execution.',
    'phy002_acceptance': 'incomplete', 'outcome': 'expected_current_source_replay_outcomes_observed',
    'source_archive': {'identity_before': archive_identity_before, 'identity_after': archive_identity_after,
                       'unchanged': True, 'regular_safe_unique_members': True,
                       'files': len(members), 'all_indexed_member_sizes_and_hashes_verified': True,
                       'artifact_manifest_sha256': sha(data['artifact-manifest.json']),
                       'prior_summary_sha256': sha(prior_raw), 'archive_matched_prior_summary': True},
    'inputs': inputs,
    'original_producer_identity_from_immutable_evidence': prior['native_producer'],
    'current_declared_binary': {'identity_before': binary_before, 'identity_after': binary_after,
                                'executed_in_this_replay': False, 'candidate_production_attested': False,
                                'identity_matches_original_record': binary_before['sha256'] == prior['native_producer']['sha256_before']},
    'source_sha256_before': source_before, 'source_sha256_after': source_after, 'sources_unchanged': True,
    'changes_since_prior_native_replay': {name: {'prior': value, 'current': source_before[name]}
                                        for name, value in prior['source_sha256_before'].items() if value != source_before[name]},
    'focused_tests': {'rerun': False, 'recorded_exit_code': test_meta['exit_code'],
                      'recorded_test_count': 74, 'recorded_unittest_elapsed_s': 2.966,
                      'recorded_outer_elapsed_s': test_meta['elapsed_s'],
                      'log': {'file': 'focused-tests/contact-wave2-focused-final.log', 'sha256': sha(test_log_raw), 'bytes': len(test_log_raw)},
                      'metadata': {'file': 'focused-tests/contact-wave2-focused-final.json', 'sha256': sha(test_meta_raw), 'bytes': len(test_meta_raw)},
                      'recorded_log_hash_verified': True, 'recorded_before_after_hashes_equal': True,
                      'recorded_production_module_hashes_match_current_sources': True,
                      'recorded_test_source_differences': recorded_test_source_differences,
                      'cohort_scope': 'Actual earlier 74-test cohort. Two later test-only portability revisions were authorized separately: explicit UTF-8 stderr bytes in backend-boundary tests and capability skip for unsupported surrogate filenames. This retained log does not attest those later test edits.'},
    'diagnostic_invocations': invocations,
    'separate_incomplete_timing': [
        {'fixture': 'damped_impact', 'invocation': 'all_four_default', 'peaks': ['hammer_compression', 'hammer_force'],
         'time_status': 'not_available', 'reason': 'Optional damped timing was unrequested in the default invocation.'},
        {'fixture': 'preload_equilibrium', 'invocation': 'all_four_default', 'peaks': ['damper_compression', 'damper_force'],
         'time_status': 'unresolved_near_equilibrium', 'reason': 'Positive preload peaks remain verified value enclosures with unresolved maximizing times.'}],
    'provenance_and_schema_evolution': [
        'The current oracle and CLI source identities differ from the historical native replay; source snapshots and before/after hashes are retained separately.',
        'Current successful raw-retention records add bounded_input_bytes; manifests add input_bytes_charged_to_collection_limit. The existing unattempted_inputs field remains present. These track corrected partial-retention accounting, while the replayed full raw files remain byte-identical.',
        'No partial-retention failure was induced here. The supplied focused-test log covers that behavior at the same current production module hashes; two subsequent test-only portability edits are distinguished from that earlier cohort.',
        'Time quadrature execution durations may differ; exact substantive reference/value/time comparison outcomes are checked separately.',
        'The original native archive is read-only input. Its prior failed tracing attempts and original producer provenance are preserved in the immutable original archive.'],
    'limitations': ['Four synthetic fixtures only; no physical measurements or instrument-fidelity claim.',
                    'Candidate sign-change coverage remains uncertified; general continuous-extrema acceptance remains incomplete.',
                    'Supplemental damped timing does not amend frozen acceptance; numerical refinement and quadrature errors are not certificates.',
                    'The current declared binary is hashed only; the archive records original production, and this replay does not attest arbitrary candidate physical parameters.',
                    'No native producer, broad test suite, or focused test suite was executed in this replay.'],
    'staging_directory': str(stage)}
write_json(stage / 'summary-core.json', summary)
files = []
for path in sorted(stage.rglob('*')):
    if path.is_file():
        files.append({'path': str(path.relative_to(stage)), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())})
write_json(stage / 'artifact-manifest.json', {'archive_root': FINAL_PREFIX, 'files': files})
with FINAL_TAR.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:gz') as tar:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                tar.add(path, arcname=FINAL_PREFIX + '/' + str(path.relative_to(stage)), recursive=False)
with tarfile.open(FINAL_TAR, 'r:gz') as tar:
    final_members = tar.getmembers()
    assert len({m.name for m in final_members}) == len(final_members)
    assert all(m.isfile() and safe_name(m.name) and m.name.startswith(FINAL_PREFIX + '/') for m in final_members)
    for m in final_members:
        relative = m.name[len(FINAL_PREFIX) + 1:]
        raw = tar.extractfile(m).read()
        assert raw == (stage / relative).read_bytes()
summary['archive'] = {**identity(FINAL_TAR), 'files': len(final_members),
                      'all_member_bytes_verified': True, 'member_names_relative_and_safe': True,
                      'uncompressed_file_bytes': sum(m.size for m in final_members),
                      'artifact_manifest': FINAL_PREFIX + '/artifact-manifest.json',
                      'artifact_manifest_sha256': sha((stage / 'artifact-manifest.json').read_bytes())}
write_json(FINAL_JSON, summary)
print(json.dumps({'summary': identity(FINAL_JSON), 'archive': summary['archive'],
                  'staging_directory': str(stage), 'returncodes': [inv['returncode'] for inv in invocations],
                  'versions': invocations[1]['versions'],
                  'source_changes_since_native': summary['changes_since_prior_native_replay'],
                  'difference_paths': {inv['id']: {case['fixture']: {'reference': [d['path'] for d in case['reference_differences']],
                                                                  'comparison': [d['path'] for d in case['comparison_differences']]}
                                                       for case in inv['prior_comparison']} for inv in invocations}}, indent=2))

#!/usr/bin/env python3
"""Replay the frozen recorder on final bundles; compare to retained legacy PCM.

This is a current-only fresh capture, not a new execution of the baseline
modules or a rerun of the official 216-process comparator entry point. The
unmodified retained comparator supplies capture, validation and pair checks.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
from pathlib import Path
import importlib.util
import json
import platform
import sys
import uuid


ROOT = Path(__file__).resolve().parent
RETAINED = ROOT / "retained-extracted"
COMPARATOR = RETAINED / "source/tested/tools/compare_vst3_legacy.py"
spec = importlib.util.spec_from_file_location("frozen_legacy_comparator", COMPARATOR)
compare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(compare)


def inventory(root):
    return {str(p.relative_to(root)): {"bytes": p.stat().st_size,
                                      "sha256": compare.file_hash(p)}
            for p in sorted(root.rglob("*")) if p.is_file()}


def main():
    frozen = json.loads((ROOT / "frozen-inputs.json").read_text())
    old = json.loads((RETAINED / "w4-003/comparison/report.json").read_text())
    old_dir = RETAINED / "w4-003/comparison" / old["raw_directory"]
    archive_manifest = json.loads((ROOT / "retained-input/manifest.json").read_text())
    all_historical_ids = set()
    for name in ("w4-001", "w4-003"):
        prior = json.loads((RETAINED / name / "comparison/report.json").read_text())
        all_historical_ids.update(c["capture_id"] for c in prior["captures"])
    capture = ROOT / "rhodes_vst3_legacy_capture"
    bundles = ROOT / "VST3/Release"
    sources = ROOT / "frozen-source"
    run_dir = ROOT / ("fresh-run-" + uuid.uuid4().hex)
    run_dir.mkdir()
    report = {
        "schema_version": 1, "status": "incomplete", "started_utc": compare.utc_now(),
        "kind": "Fresh final-bundle captures versus retained raw legacy oracle",
        "baseline_native_execution_performed": False,
        "current_native_execution_performed": True,
        "official_216_process_entry_point_rerun": False,
        "environment": {"platform": platform.platform(), "machine": platform.machine(),
                        "python": platform.python_version(), "byte_order": sys.byteorder},
        "run_directory": run_dir.name,
        "retained_report": {"path": str(RETAINED / "w4-003/comparison/report.json"),
                            "sha256": compare.file_hash(RETAINED / "w4-003/comparison/report.json")},
        "baseline_revision": old["baseline_revision"],
        "baseline_module_identities": old["modules"]["baseline"],
        "capture_executable": {"path": str(capture), "sha256": compare.file_hash(capture),
                               "retained_sha256": old["capture_executable"]["sha256"]},
        "comparator": {"path": str(COMPARATOR), "sha256": compare.file_hash(COMPARATOR)},
        "harness": {"path": str(Path(__file__)), "sha256": compare.file_hash(Path(__file__))},
        "captures": [], "retained_baseline_captures": [], "pairs": [],
        "dense_partition_comparisons": [],
        "limitations": [
            "The 72 baseline captures are retained records, not fresh baseline processes.",
            "Only valid synthetic stereo timelines at neutral panel and unity Expression are covered.",
            "No acoustic/physical fidelity, named DAW, audio-device, deadline, mono or other-platform claim.",
            "Source hashes describe observed inputs; module hashes identify what actually executed.",
        ],
    }
    compare.write_json(ROOT / "fresh-comparison.json", report)
    oracle_runs = {}
    fresh_runs = {}
    try:
        compare.require(old["status"] == "passed", "retained official gate not passed")
        compare.require(compare.file_hash(capture) == old["capture_executable"]["sha256"],
                        "recorder must be byte-identical to retained recorder")
        compare.require(compare.file_hash(COMPARATOR) == frozen["source_files"]["tools/compare_vst3_legacy.py"]["frozen_sha256"],
                        "current and retained comparator source differ")
        archive_before = compare.file_hash(ROOT / "retained-input/legacy-audio-evidence.tar.xz")
        compare.require(archive_before == archive_manifest["archive"]["sha256"], "archive identity")
        modules_before = compare.bundle_inventory(bundles)
        sources_before = compare.source_fingerprints(sources)
        raw_oracle_before = inventory(old_dir)
        report["current_modules"] = modules_before
        report["current_source_fingerprints"] = sources_before
        for record in old["captures"]:
            if record["mode"] != "baseline":
                continue
            key = (record["variant"], record["format_bits"], record["sample_rate_hz"],
                   record["partition"], record["gain_workload"])
            for kind in ("stdout", "stderr", "trace"):
                path = old_dir / record[kind + "_path"]
                compare.require(compare.file_hash(path) == record[kind + "_sha256"], "retained raw hash")
                compare.require(path.stat().st_size == record[kind + "_bytes"], "retained raw size")
                member = str(path.relative_to(RETAINED))
                compare.require(compare.file_hash(path) == archive_manifest["files"][member]["sha256"],
                                "retained archive member hash")
            metadata = compare.strict_json(compare.read_bounded(old_dir / record["stdout_path"], compare.MAX_METADATA_BYTES))
            audio = compare.read_bounded(old_dir / record["trace_path"], compare.TOTAL_FRAMES * 2 * (record["format_bits"] // 8))
            validated = compare.validate_capture(metadata, audio, capture_id=record["capture_id"],
                                                 mode="baseline", variant=key[0], format_bits=key[1],
                                                 rate=key[2], partition=key[3], workload=key[4])
            compare.require(all(record[k] == v for k, v in validated.items()), "retained revalidation differs")
            compare.require(key not in oracle_runs, "duplicate oracle fixture")
            oracle_runs[key] = (record, metadata, audio)
            report["retained_baseline_captures"].append(record)
        fixtures = list(product(compare.VARIANTS, compare.FORMATS, compare.RATES,
                                compare.PARTITIONS, compare.WORKLOADS))
        compare.require(set(oracle_runs) == set(fixtures), "retained fixture coverage")
        work = [(key, mode) for key in fixtures for mode in ("default", "explicit1")]
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [(key, mode, pool.submit(compare.one_capture, capture, bundles, run_dir,
                                               key, mode, 30.0)) for key, mode in work]
            for key, mode, future in futures:
                result = future.result()
                fresh_runs[(mode,) + key] = result
                report["captures"].append(result[0])
                pair = compare.compare_pair(oracle_runs[key], result)
                pair.update(variant=key[0], format_bits=key[1], sample_rate_hz=key[2],
                            partition=key[3], gain_workload=key[4],
                            baseline_evidence="retained-w4-003")
                report["pairs"].append(pair)
                print(("PASS" if pair["passed"] else "FAIL"), mode, *key, flush=True)
        for mode, variant, bits, rate in product(compare.MODES, compare.VARIANTS, compare.FORMATS, compare.RATES):
            selected = [(oracle_runs[(variant, bits, rate, partition, "dense")] if mode == "baseline"
                         else fresh_runs[(mode, variant, bits, rate, partition, "dense")])
                        for partition in compare.PARTITIONS]
            passed = all(r[0]["passed"] for r in selected) and len({r[0]["audio_sha256"] for r in selected}) == 1
            report["dense_partition_comparisons"].append({
                "mode": mode, "variant": variant, "format_bits": bits, "sample_rate_hz": rate,
                "evidence": "retained" if mode == "baseline" else "fresh",
                "three_partitions_exact": passed})
        fresh_ids = [r["capture_id"] for r in report["captures"]]
        fresh_ids_ok = len(set(fresh_ids)) == 144 and not (set(fresh_ids) & all_historical_ids)
        unchanged = (modules_before == compare.bundle_inventory(bundles)
                     and sources_before == compare.source_fingerprints(sources)
                     and raw_oracle_before == inventory(old_dir)
                     and compare.file_hash(capture) == report["capture_executable"]["sha256"]
                     and compare.file_hash(COMPARATOR) == report["comparator"]["sha256"]
                     and archive_before == compare.file_hash(ROOT / "retained-input/legacy-audio-evidence.tar.xz"))
        complete = len(report["captures"]) == 144 and len(oracle_runs) == 72 and len(report["pairs"]) == 144
        passed = (complete and unchanged and fresh_ids_ok
                  and all(r["passed"] for r in report["captures"])
                  and all(r["passed"] for r in report["pairs"])
                  and all(r["three_partitions_exact"] for r in report["dense_partition_comparisons"]))
        report["summary"] = {
            "passed": passed, "complete": complete, "fixtures": len(fixtures),
            "retained_valid_baseline_captures": len(oracle_runs), "fresh_loaded_processes": len(report["captures"]),
            "fresh_valid_captures": sum(r["passed"] for r in report["captures"]),
            "passed_pairs": sum(r["passed"] for r in report["pairs"]),
            "paired_stereo_frames": len(report["pairs"]) * compare.TOTAL_FRAMES,
            "fresh_callbacks_total": sum(r.get("callbacks", 0) for r in report["captures"]),
            "fresh_capture_ids_unique_and_disjoint_from_all_retained": fresh_ids_ok,
            "fresh_dense_groups_passed": sum(r["three_partitions_exact"] for r in report["dense_partition_comparisons"] if r["evidence"] == "fresh"),
            "retained_dense_groups_passed": sum(r["three_partitions_exact"] for r in report["dense_partition_comparisons"] if r["evidence"] == "retained"),
            "all_frozen_inputs_unchanged": unchanged,
        }
        report["status"] = "passed" if passed else "failed"
    except Exception as error:
        report["status"] = "failed"
        report["error"] = repr(error)
        print("FAIL:", repr(error), file=sys.stderr)
    finally:
        compare.write_json(run_dir / "commands.json", report["captures"])
        manifest = {"schema_version": 1, "files": inventory(run_dir)}
        compare.write_json(run_dir / "manifest.json", manifest)
        report["raw_manifest_sha256"] = compare.file_hash(run_dir / "manifest.json")
        report["raw_manifest_file_count"] = len(manifest["files"])
        report["raw_records_match_manifest"] = compare.raw_records_match_manifest(report["captures"], manifest)
        if not report["raw_records_match_manifest"]:
            report["status"] = "failed"
        report["completed_utc"] = compare.utc_now()
        compare.write_json(ROOT / "fresh-comparison.json", report)
        compare.write_json(run_dir / "report.json", report)
    print(json.dumps(report.get("summary", {}), indent=2, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())

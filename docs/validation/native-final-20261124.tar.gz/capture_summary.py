"""Read-only analysis of fetched CI text; no builds, tests or archived commands run.

Run from the repository root after the connector retrieval has populated this
directory. The full API payload describes the exact endpoints and normalization.
Output files are created exclusively after source/log/member consistency checks.
"""
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


ROOT = Path.cwd()
CAPTURE = ROOT / "build/w5-88-native-capture"
FINAL_JSON = ROOT / "docs/validation/native-final-20261124.json"
FINAL_ARCHIVE = ROOT / "docs/validation/native-final-20261124.tar.gz"
TESTED = "240170673983f9992e4657a2d96c2172ece1ac30"
EXPECTED_CTEST = {
    "core-linux": (150, 150, 0),
    "core-windows": (147, 147, 0),
    "core-macos": (147, 141, 6),
    "sanitizers-linux": (150, 150, 0),
    "vst3-linux": (138, 138, 0),
    "vst3-windows": (134, 134, 0),
    "vst3-macos": (134, 125, 9),
}
EXPECTED_PYTHON_SKIPS = {"python-linux": 20, "python-windows": 23, "python-macos": 21}
SDK_PINS = {
    ".": "3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96",
    "base": "fcf9da0bd27a16f7f03773a3a39822f28f5c8477",
    "cmake": "054c9143cbb8d47fc4694e473f2ee3b4d951a8f5",
    "pluginterfaces": "4f547e8e102b47de4a8b8aaf343c73b700786372",
    "public.sdk": "586dc5e6c8012c3e4b01c79389375cbe96bdb1da",
}
VALIDATORS = [
    "vst3.sdk_validator", "vst3.filtered_sdk_validator",
    "vst3.quadrature_sdk_validator", "vst3.moduleinfo_validator",
    "vst3.filtered_moduleinfo_validator", "vst3.quadrature_moduleinfo_validator",
]
QENGINE = ["quadrature.qengine_" + suffix for suffix in
           ("events", "partitions", "prepare", "faults", "allocations")]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args])


def plain_lines(data):
    # Parsing only: archived bytes retain BOM, timestamps, ANSI and whitespace.
    text = data.decode("utf-8")
    text = re.sub(r"\x1b\[[0-9;]*m", "", text)
    return [re.sub(r"^\ufeff?\d{4}-\d\d-\d\dT\S+Z ", "", line)
            for line in text.splitlines()]


def group(lines, name):
    start = lines.index("##[group]" + name) + 1
    return lines[start:lines.index("##[endgroup]", start)]


def main():
    assert not FINAL_JSON.exists() and not FINAL_ARCHIVE.exists()
    records = json.loads((CAPTURE / "api-records.json").read_text(encoding="utf-8"))
    runs = [records["foundation_run"], records["vst3_run"]]
    jobs = records["foundation_jobs"]["jobs"] + records["vst3_jobs"]["jobs"]
    assert records["foundation_jobs"]["total_count"] == 7
    assert records["vst3_jobs"]["total_count"] == 3
    assert len(jobs) == len({j["id"] for j in jobs}) == 10
    for record in runs + jobs:
        assert record["head_sha"] == TESTED
        assert record["status"] == "completed" and record["conclusion"] == "success"
    by_job = {j["id"]: j for j in jobs}
    observed_head_before = git("rev-parse", "HEAD").decode().strip()
    tested_tree = git("rev-parse", TESTED + "^{tree}").decode().strip()
    historical = json.loads((ROOT / "docs/validation/native-platforms-20261124.json").read_text())
    original_paths = set(historical["source_sha256"])
    all_paths = git("ls-tree", "-r", "--name-only", TESTED).decode().splitlines()
    native_paths = sorted(p for p in all_paths if p in (
        "CMakeLists.txt", "CMakePresets.json", ".github/workflows/ci.yml", ".github/workflows/vst3.yml"
    ) or p.startswith(("include/", "src/", "plugins/vst3/", "tests/cpp/", "apps/", "cmake/")))
    python_paths = sorted(p for p in all_paths if p.endswith(".py") and
                          p.startswith(("tools/", "tests/python/")))
    assert len(original_paths) == 74 and original_paths <= set(native_paths)
    assert len(native_paths) == 83 and len(python_paths) == 65
    source_sha = {p: sha(git("show", TESTED + ":" + p))
                  for p in sorted(set(native_paths + python_paths))}
    local_before = {p: sha((ROOT / p).read_bytes()) for p in source_sha}
    assert local_before == source_sha
    earlier_differences = sorted(p for p in original_paths
                                 if historical["source_sha256"][p] != source_sha[p])
    assert earlier_differences == ["tests/cpp/quadrature_engine_test.cpp"]

    results = []
    log_members = {}
    pattern = re.compile(r"\s?(\d+)/(\d+) Test\s+#(\d+):\s+(\S+)\s+\.*\s*"
                         r"(Passed|\*\*\*Skipped|\*\*\*Failed)\s+(\S+)\s+sec")
    for item in records["inventory"]:
        name, label = item["filename"], item["label"]
        data = (CAPTURE / name).read_bytes()
        assert b"\r" not in data and data.endswith(b"\n") and not data.endswith(b"\n\n")
        log_members[name] = data
        lines = plain_lines(data)
        job = by_job[item["job_id"]]
        row = {
            "job_id": job["id"], "label": label, "name": job["name"],
            "html_url": job["html_url"], "status": job["status"],
            "conclusion": job["conclusion"], "head_sha": job["head_sha"],
            "started_at": job["started_at"], "completed_at": job["completed_at"],
            "operating_system_lines": group(lines, "Operating System"),
            "runner_image_lines": group(lines, "Runner Image"),
            "log_member": name, "log_bytes": len(data), "log_sha256": sha(data),
            "observed_run_commands": [s.removeprefix("##[group]Run ") for s in lines
                                      if s.startswith("##[group]Run ")],
        }
        compiler = [s.split("identification is ", 1)[1] for s in lines
                    if s.startswith("-- The CXX compiler identification is ")]
        if compiler:
            assert len(compiler) == 1
            row["cxx_compiler"] = compiler[0]
        python_version = [re.fullmatch(r"Successfully set up CPython \(([^)]+)\)", s)
                          for s in lines]
        python_version = [m.group(1) for m in python_version if m]
        if python_version:
            assert len(python_version) == 1
            row["setup_python_version"] = python_version[0]

        if label in EXPECTED_CTEST:
            matches = [pattern.search(s) for s in lines]
            matches = [m.groups() for m in matches if m]
            count = Counter(m[4] for m in matches)
            expected = EXPECTED_CTEST[label]
            assert (len(matches), count["Passed"], count["***Skipped"]) == expected
            assert count["***Failed"] == 0
            assert {int(m[1]) for m in matches} == {expected[0]}
            assert sorted(int(m[0]) for m in matches) == list(range(1, expected[0] + 1))
            assert len({m[3] for m in matches}) == len(matches)
            status = {m[3]: m[4] for m in matches}
            row["ctest"] = {
                "registered_tests": len(matches), "passed_tests": count["Passed"],
                "failed_tests": 0,
                "skipped_tests": [m[3] for m in matches if m[4] == "***Skipped"],
            }
            if label.startswith("vst3-"):
                for selector in VALIDATORS:
                    assert status[selector] == "Passed"
                pins = dict(m.groups() for s in lines
                            if (m := re.fullmatch(r"(\.|base|cmake|pluginterfaces|public.sdk): ([0-9a-f]{40})", s)))
                assert pins == SDK_PINS
                row["sdk_pins_printed_and_verified"] = pins
                row["ctest"]["sdk_and_metadata_validators"] = {s: status[s] for s in VALIDATORS}
                row["ctest"]["additional_reviewed_selectors"] = {
                    s: v for s, v in status.items()
                    if any(k in s for k in ("scalar_output", "allocation_guard", "module_coexist", "module_duplicate_guard", "bundle_resources"))
                }
                assert all(v == "Passed" for v in row["ctest"]["additional_reviewed_selectors"].values())
                archive_steps = [s for s in job["steps"] if s["name"] in (
                    "Archive all three validated experimental bundles", "Upload validated experimental bundles"
                )]
                assert len(archive_steps) == 2 and all(s["conclusion"] == "success" for s in archive_steps)
                archive_lines = [s for s in lines if re.match(r"Verified \d+ entries in ", s)]
                assert len(archive_lines) == 1
                row["bundle_archive_steps"] = archive_steps
                row["bundle_archive_log_line"] = archive_lines[0]
            else:
                for selector in QENGINE:
                    assert status[selector] == "Passed"
                row["ctest"]["quadrature_engine_selectors"] = {s: status[s] for s in QENGINE}
        else:
            assert label in EXPECTED_PYTHON_SKIPS
            summaries = [re.fullmatch(r"Ran (\d+) tests in ([\d.]+)s", s) for s in lines]
            summaries = [m for m in summaries if m]
            endings = [re.fullmatch(r"OK \(skipped=(\d+)\)", s) for s in lines]
            endings = [m for m in endings if m]
            skips = [s for s in lines if re.match(r"test_\S+ \(.+\) \.\.\. skipped ", s)]
            assert len(summaries) == len(endings) == 1
            assert int(summaries[0][1]) == 584
            assert int(endings[0][1]) == len(skips) == EXPECTED_PYTHON_SKIPS[label]
            row["python"] = {
                "reported_count_including_skips": 584, "unskipped_passes": 584 - len(skips),
                "skipped_count": len(skips), "skipped_verbose_lines": skips,
                "duration_seconds": float(summaries[0][2]), "result": "OK",
            }
        results.append(row)

    artifacts_payload = records["vst3_artifacts"]
    artifacts = artifacts_payload["artifacts"]
    assert artifacts_payload["total_count"] == len(artifacts) == 3
    assert len({a["name"] for a in artifacts}) == 3
    for artifact in artifacts:
        assert artifact["workflow_run"]["head_sha"] == TESTED
        assert artifact["workflow_run"]["id"] == records["vst3_run"]["id"]
        assert not artifact["expired"] and TESTED in artifact["name"]
        assert re.fullmatch(r"sha256:[0-9a-f]{64}", artifact["digest"])

    members = dict(log_members)
    members["api-records.json"] = (CAPTURE / "api-records.json").read_bytes()
    members["capture_summary.py"] = Path(__file__).read_bytes()
    raw_tar = io.BytesIO()
    with tarfile.open(fileobj=raw_tar, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(members.items()):
            assert re.fullmatch(r"[A-Za-z0-9._-]+", name)
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(data))
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode="wb", filename="", mtime=0, compresslevel=9) as stream:
        stream.write(raw_tar.getvalue())
    archive_bytes = compressed.getvalue()
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
        assert archive.getnames() == sorted(members)
        for info in archive:
            assert info.isfile() and not info.issym() and not info.islnk()
            assert info.mode == 0o644 and info.mtime == info.uid == info.gid == 0
            assert archive.extractfile(info).read() == members[info.name]

    local_after = {p: sha((ROOT / p).read_bytes()) for p in source_sha}
    assert local_before == local_after == source_sha
    observed_head_after = git("rev-parse", "HEAD").decode().strip()
    output = {
        "schema_version": 1, "kind": "retained-native-ci-validation",
        "evaluator": "/root/w5_88_current_native_archive",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_commit": TESTED, "source_tree": tested_tree,
        "scope": "Retained completed hosted runs at the exact latest C++ test checkpoint; no local build or test was executed by this collection.",
        "retrieval": records["retrieval"],
        "source_applicability": {
            "observed_local_head_before": observed_head_before,
            "observed_local_head_after": observed_head_after,
            "native_source_count": len(native_paths), "native_source_paths": native_paths,
            "python_tool_test_source_count": len(python_paths), "python_tool_test_source_paths": python_paths,
            "source_sha256_at_tested_commit": source_sha,
            "all_148_listed_sources_match_current_bytes_before_and_after": True,
            "historical_native_manifest_source_commit": historical["source_commit"],
            "historical_native_manifest_path_count": len(original_paths),
            "differences_from_historical_74_file_manifest": earlier_differences,
            "additional_native_build_workflow_paths": sorted(set(native_paths) - original_paths),
            "note": "Git show of the tested commit supplied every manifest digest; local bytes were compared before/after collection. Later documentation, evidence, state and campaign metadata are not relabeled as executed at this checkpoint. The tested Git tree binds other committed inputs; the current local comparison is limited to the listed source/build/workflow paths.",
        },
        "sdk_pins": SDK_PINS,
        "ci_runs": [{k: r[k] for k in ("id", "name", "html_url", "event", "head_branch", "head_sha", "status", "conclusion", "created_at", "updated_at", "run_attempt")} for r in runs],
        "job_results": results,
        "vst3_artifact_metadata": artifacts,
        "artifact_metadata_limit": "Names, sizes, SHA-256 digests and expiry are reported by the GitHub API. This assignment did not download or byte-verify the uploaded bundle artifacts. Archive/upload job steps and their log checks succeeded.",
        "archive": {
            "path": FINAL_ARCHIVE.name, "bytes": len(archive_bytes), "sha256": sha(archive_bytes),
            "member_count": len(members),
            "members": {name: {"bytes": len(data), "sha256": sha(data)} for name, data in sorted(members.items())},
            "normalization": records["retrieval"]["normalization"],
            "format": "Flat regular-file USTAR, sorted names, mode0644, uid/gid/mtime0; gzip filename empty and mtime0, compression level9. Member bytes verified in memory, without extraction or execution.",
        },
        "collection_command": "python3 build/w5-88-native-capture/capture_summary.py",
        "collection_script_member": "capture_summary.py",
        "limitations": [
            "Seven CTest runs and three Python CI runs are separate jobs. Registered CTest counts and unittest summary counts include explicitly listed skips; skips are not represented as passes.",
            "macOS ARM skips six core and nine VST3 x86 MXCSR FTZ/DAZ modes. All five quadrature-engine selectors pass in each core/sanitizer job.",
            "The four module coexistence/duplicate-guard selectors are Linux-only; no macOS or Windows execution is inferred.",
            "CI Python3.11 uses platform-specific versions and optional-backend/capability skips. The later local Python3.12/NumPy/SciPy run is separate evidence.",
            "Decoded normalized text hashes bind retained bytes, not original server ZIP bytes, independent log authenticity or binary reproducibility.",
            "Native success and sanitizer observations do not establish every host, compiler flag, concurrency schedule, allocator operation or audio-device deadline.",
            "No DAW session, measured specimen fidelity, minimum deployment baseline, publisher signing/notarization or product release is established. SDK ad-hoc signing messages in the macOS build are not publisher release signing.",
        ],
    }
    with FINAL_ARCHIVE.open("xb") as stream:
        stream.write(archive_bytes)
    encoded = (json.dumps(output, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    with FINAL_JSON.open("xb") as stream:
        stream.write(encoded)
    print(json.dumps({"json": {"path": str(FINAL_JSON.relative_to(ROOT)), "bytes": len(encoded), "sha256": sha(encoded)}, "archive": {"path": str(FINAL_ARCHIVE.relative_to(ROOT)), "bytes": len(archive_bytes), "sha256": sha(archive_bytes)}, "members": len(members), "sources": len(source_sha)}, indent=2))


if __name__ == "__main__":
    main()

import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

OUT = Path('/dev/shm/rhodes-d-w046')
ROOT = Path('/workspace/scratch/68ec02e60e7e/Fender-rhoades')
variant, fixture, leaks, label = sys.argv[1:]
command = [str(OUT / variant / (fixture + '-asan-ubsan')), 'all']
settings = {'ASAN_OPTIONS': 'halt_on_error=1:detect_leaks=' + leaks,
            'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
env = os.environ.copy()
env.update(settings)
log = OUT / ('run-' + label + '.log')
started_at = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
started = time.monotonic()
with log.open('w') as stream:
    stream.write('$ ' + ' '.join(k + '=' + shlex.quote(v) for k,v in settings.items()) +
                 ' ' + shlex.join(command) + '\n')
    stream.flush()
    try:
        done = subprocess.run(command, cwd=ROOT, env=env, stdout=stream,
                              stderr=subprocess.STDOUT, timeout=180)
        exit_code = done.returncode
    except subprocess.TimeoutExpired:
        exit_code = 124
        stream.write('\nTIMEOUT after 180 seconds\n')
    stream.write('\nexit_code=' + str(exit_code) + '\n')
text = log.read_text()
result = {'variant': variant, 'fixture': fixture, 'label': label,
          'command': command, 'environment': settings, 'started_at': started_at,
          'elapsed_seconds': round(time.monotonic() - started, 3),
          'exit_code': exit_code, 'log': str(log),
          'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
          'pass_selectors': re.findall(r'^PASS ([a-z_]+)', text, re.MULTILINE)}
path = OUT / 'run-results.json'
results = json.loads(path.read_text()) if path.exists() else []
results.append(result)
path.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(result, indent=2))
if exit_code:
    print(text)
raise SystemExit(0 if exit_code == 0 else 1)

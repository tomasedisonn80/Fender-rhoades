import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import time

ROOT = Path('/workspace/scratch/68ec02e60e7e/Fender-rhoades')
OUT = Path('/dev/shm/rhodes-d-w046')
SDK = Path('/workspace/scratch/d6370337c6a4/vst3sdk')
LIB = Path('/tmp/rhodes-d-build/lib/Release')
SOURCES = ['src/research_engine.cpp', 'plugins/vst3/processor.cpp',
           'plugins/vst3/state_stream.cpp', 'plugins/vst3/controller.cpp']
FIXTURES = {'mono': 'tests/cpp/vst3_mono_contract_test.cpp',
            'bounds': 'tests/cpp/vst3_expression_bounds_test.cpp',
            'concurrency': 'tests/cpp/vst3_expression_concurrency_test.cpp'}
VARIANTS = {'direct': [], 'filtered': ['-DRHODES_FILTERED_VST3=1'],
            'quadrature': ['-DRHODES_QUADRATURE_VST3=1']}
LIBS = [LIB / name for name in ('libsdk.a', 'libsdk_common.a', 'libbase.a', 'libpluginterfaces.a')]
FLAGS = ['-std=gnu++20', '-O1', '-g1', '-DNDEBUG', '-DRELEASE=1',
         '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
         '-fno-sanitize-recover=all', '-pthread', '-I' + str(ROOT),
         '-I' + str(ROOT / 'include'), '-isystem', str(SDK)]

def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    paths = SOURCES + list(FIXTURES.values()) + ['tests/cpp/vst3_test_support.hpp']
    paths += [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'include/rhodes').glob('*.hpp'))
              if p.name != 'contact_reference.hpp']
    paths += [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'plugins/vst3').glob('*.hpp'))]
    return {p: {'sha256': sha(ROOT / p), 'bytes': (ROOT / p).stat().st_size} for p in sorted(set(paths))}

manifest = {
    'schema_version': 1, 'assignment': 'continuation-d/w3-046',
    'started_at': utc(), 'repo': str(ROOT), 'private_dir': str(OUT),
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_before': snapshot(),
    'sdk_root': str(SDK),
    'sdk_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SDK, text=True).strip(),
    'sdk_archives_before': {str(p): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in LIBS},
    'compiler': subprocess.check_output(['g++', '--version'], text=True).strip(),
    'platform': platform.platform(), 'compile_flags': FLAGS,
    'sanitizer_scope': 'Every project translation unit and fixture compiled below is instrumented; linked SDK archives are prebuilt and uninstrumented.',
    'git_status_at_start': subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True),
    'compile_commands': [], 'link_commands': [], 'runs': []}
(OUT / 'manifest-before.json').write_text(json.dumps(manifest, indent=2) + '\n')


def execute(label, command):
    started = time.monotonic()
    at = utc()
    log = OUT / (label + '.log')
    with log.open('w') as stream:
        stream.write('$ ' + shlex.join(command) + '\n')
        stream.flush()
        done = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        stream.write('\nexit_code=' + str(done.returncode) + '\n')
    result = {'label': label, 'command': command, 'started_at': at,
              'elapsed_seconds': round(time.monotonic() - started, 3),
              'exit_code': done.returncode, 'log': str(log), 'log_sha256': sha(log)}
    print(label + ': exit=' + str(done.returncode) + ' elapsed=' + str(result['elapsed_seconds']), flush=True)
    return result

jobs = []
for variant, definitions in VARIANTS.items():
    directory = OUT / variant
    directory.mkdir(exist_ok=True)
    for source in SOURCES + list(FIXTURES.values()):
        stem = Path(source).stem
        target = directory / (stem + '.o')
        command = ['g++'] + FLAGS + definitions + ['-MMD', '-MF', str(directory / (stem + '.d')),
                  '-c', str(ROOT / source), '-o', str(target)]
        jobs.append((f'build-{variant}-{stem}', command))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(execute, label, command) for label, command in jobs]
    for future in futures:
        manifest['compile_commands'].append(future.result())
(OUT / 'build-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
if any(item['exit_code'] != 0 for item in manifest['compile_commands']):
    raise SystemExit('Compile failure; inspect retained build logs')
for variant in VARIANTS:
    directory = OUT / variant
    objects = [str(directory / (Path(source).stem + '.o')) for source in SOURCES]
    for fixture, source in FIXTURES.items():
        target = directory / (fixture + '-asan-ubsan')
        command = ['g++', '-O1', '-g1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                   '-fno-sanitize-recover=all', '-pthread',
                   str(directory / (Path(source).stem + '.o'))] + objects + [str(p) for p in LIBS] + [
                   '-lstdc++fs', '-lpthread', '-ldl', '-o', str(target)]
        result = execute(f'link-{variant}-{fixture}', command)
        manifest['link_commands'].append(result)
        (OUT / 'build-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        if result['exit_code']:
            raise SystemExit('Link failure; inspect retained link logs')
manifest['build_finished_at'] = utc()
manifest['source_after_build'] = snapshot()
manifest['source_unchanged_after_build'] = manifest['source_before'] == manifest['source_after_build']
manifest['project_objects'] = {str(p.relative_to(OUT)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                               for p in sorted(OUT.glob('*/*.o'))}
manifest['executables'] = {str(p.relative_to(OUT)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                          for p in sorted(OUT.glob('*/*-asan-ubsan'))}
(OUT / 'build-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Build complete; source unchanged=' + str(manifest['source_unchanged_after_build']), flush=True)

import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT=Path('/workspace/scratch/68ec02e60e7e/Fender-rhoades')
OUT=Path('/dev/shm/rhodes-d-w046')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((OUT/'build-manifest.json').read_text())
m['runs']=json.loads((OUT/'run-results.json').read_text())
m['instrumentation_audit']=json.loads((OUT/'instrumentation.json').read_text())
m['source_after_runs']={p:{'sha256':sha(ROOT/p),'bytes':(ROOT/p).stat().st_size} for p in m['source_before']}
m['source_unchanged_after_runs']=m['source_before']==m['source_after_runs']
m['sdk_archives_after_runs']={p:{'sha256':sha(Path(p)),'bytes':Path(p).stat().st_size} for p in m['sdk_archives_before']}
m['sdk_archives_unchanged']=m['sdk_archives_before']==m['sdk_archives_after_runs']
expected={'mono':['negotiation','scalar','pointers','omission','flush','rejection','lifecycle'],
          'bounds':['queue_limits','persistent_limits','maximum_points','command_events','dispatch','allocations'],
          'concurrency':['mailbox_ordered','host_preflight','adaptive_snapshots','live_anchors','callback_stress']}
final=[r for r in m['runs'] if r['environment']['ASAN_OPTIONS']=='halt_on_error=1:detect_leaks=0']
assert len(final)==9
assert {(r['variant'],r['fixture']) for r in final}=={(v,f) for v in ('direct','filtered','quadrature') for f in expected}
assert all(r['exit_code']==0 and r['pass_selectors']==expected[r['fixture']] for r in final)
assert m['source_unchanged_after_runs'] and m['sdk_archives_unchanged']
assert m['instrumentation_audit']['all_objects_reference_asan_and_ubsan']
assert not m['instrumentation_audit']['dependencies_missing_from_before_snapshot']
mono=[]; bounds=[]; concurrency=[]; diagnostics=[]
for r in final:
    text=Path(r['log']).read_text()
    diagnostics += re.findall(r'^.*(?:ERROR: AddressSanitizer|runtime error:|SUMMARY: (?:AddressSanitizer|UndefinedBehaviorSanitizer)).*$',text,re.MULTILINE)
    if r['fixture']=='mono':
        mono += [list(map(int,match)) for match in re.findall(r'\((\d+) cases, (\d+) processor calls, (\d+) guarded pointer arrays, (\d+) explicit checks\)',text)]
    elif r['fixture']=='bounds':
        bounds += [list(map(int,match)) for match in re.findall(r'(\d+) guarded callbacks: (\d+) accepted, (\d+) rejected; (\d+) point reads, (\d+) event reads',text)]
    else:
        concurrency += [list(map(int,match)) for match in re.findall(r'checks=(\d+) process_calls=(\d+) set_calls=(\d+) get_calls=(\d+)',text)]
def total(rows): return [sum(values) for values in zip(*rows)]
m['summary']={'final_executions':9,'final_exit_zero':9,'expected_selectors':54,'passed_selectors':sum(len(r['pass_selectors']) for r in final),'skipped_selectors':0,'sanitizer_diagnostics':diagnostics,
              'mono_totals':dict(zip(('cases','processor_calls','guarded_pointer_arrays','explicit_checks'),total(mono))),
              'bounds_totals':dict(zip(('guarded_callbacks','accepted','rejected','point_reads','event_reads'),total(bounds))),
              'concurrency_totals':dict(zip(('checks','process_calls','set_calls','get_calls'),total(concurrency))),
              'first_compile_failures':sum(r['exit_code']!=0 for r in m['compile_commands']),
              'compile_retries':len(m['compile_retries']),
              'leak_enabled_attempts':1,
              'leak_enabled_successes':0}
m['limitations']=['LeakSanitizer initial attempt failed with fatal ptrace restriction; final matrix disables leak detection.','Linked SDK archives are uninstrumented; every project translation unit and fixture is instrumented.','ASan/UBSan concurrency fixture success does not constitute ThreadSanitizer or data-race proof.','No native Windows/macOS, loaded-module, DAW, device, deadline, whole-suite, mutant, or physical-fidelity claim.','C++ replacement allocation probes do not observe arbitrary C allocation, all locking, foreign hosts, or device deadlines.']
m['completed_at']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
m['head_after_runs']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
m['raw_files']={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix in ('.log','.py','.d','.json') and p.name!='hash-manifest.json'}
(OUT/'hash-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'summary':m['summary'],'source_files':len(m['source_before']),'source_unchanged':m['source_unchanged_after_runs'],'sdk_archives_unchanged':m['sdk_archives_unchanged'],'raw_files':len(m['raw_files']),'manifest_sha256':sha(OUT/'hash-manifest.json')},indent=2))

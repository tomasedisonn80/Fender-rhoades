from pathlib import Path
import subprocess
import sys
OUT=Path('/dev/shm/rhodes-d-w046')
for variant in ('direct','filtered','quadrature'):
    for fixture in ('mono','bounds','concurrency'):
        label=variant+'-'+fixture+'-leaks0'
        command=[sys.executable,str(OUT/'run_one.py'),variant,fixture,'0',label]
        result=subprocess.run(command)
        if result.returncode:
            print('STOP on failed fixture '+label,flush=True)
            raise SystemExit(result.returncode)
print('All 9 all-selector executions completed',flush=True)

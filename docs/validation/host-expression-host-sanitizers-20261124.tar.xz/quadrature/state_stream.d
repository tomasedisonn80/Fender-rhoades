/dev/shm/rhodes-d-w046/quadrature/state_stream.o: \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/plugins/vst3/state_stream.cpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/plugins/vst3/state_stream.hpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/include/rhodes/instrument_state.hpp

/dev/shm/rhodes-d-w046/filtered/controller.o: \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/plugins/vst3/controller.cpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/plugins/vst3/controller.hpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/plugins/vst3/plugin_ids.hpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/plugins/vst3/state_stream.hpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/include/rhodes/instrument_state.hpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/include/rhodes/control_value.hpp \
 /workspace/scratch/68ec02e60e7e/Fender-rhoades/include/rhodes/control_text.hpp

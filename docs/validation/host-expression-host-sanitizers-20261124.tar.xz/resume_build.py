import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time
ROOT=Path('/workspace/scratch/68ec02e60e7e/Fender-rhoades')
OUT=Path('/dev/shm/rhodes-d-w046')
LIB=Path('/tmp/rhodes-d-build/lib/Release')
path=OUT/'build-manifest.json'
m=json.loads(path.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def utc(): return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def execute(label,command):
    at=utc(); started=time.monotonic(); log=OUT/(label+'.log')
    with log.open('w') as f:
        f.write('$ '+shlex.join(command)+'\n'); f.flush()
        p=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
        f.write('\nexit_code='+str(p.returncode)+'\n')
    result={'label':label,'command':command,'started_at':at,'elapsed_seconds':round(time.monotonic()-started,3),'exit_code':p.returncode,'log':str(log),'log_sha256':sha(log)}
    print(label+': '+str(p.returncode),flush=True)
    return result
m['compile_retries']=[]
for original in m['compile_commands']:
    if original['exit_code']:
        result=execute(original['label']+'-retry1',original['command'])
        m['compile_retries'].append(result)
        path.write_text(json.dumps(m,indent=2)+'\n')
        if result['exit_code']: raise SystemExit('Retry failed')
sources=['research_engine','processor','state_stream','controller']
fixtures={'mono':'vst3_mono_contract_test','bounds':'vst3_expression_bounds_test','concurrency':'vst3_expression_concurrency_test'}
libs=[str(LIB/name) for name in ('libsdk.a','libsdk_common.a','libbase.a','libpluginterfaces.a')]
for variant in ('direct','filtered','quadrature'):
    directory=OUT/variant
    objects=[str(directory/(source+'.o')) for source in sources]
    for fixture,source in fixtures.items():
        target=directory/(fixture+'-asan-ubsan')
        command=['g++','-O1','-g1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-sanitize-recover=all','-pthread',str(directory/(source+'.o'))]+objects+libs+['-lstdc++fs','-lpthread','-ldl','-o',str(target)]
        result=execute(f'link-{variant}-{fixture}',command)
        m['link_commands'].append(result)
        path.write_text(json.dumps(m,indent=2)+'\n')
        if result['exit_code']: raise SystemExit('Link failed')
m['build_finished_at']=utc()
m['source_after_build']={p:{'sha256':sha(ROOT/p),'bytes':(ROOT/p).stat().st_size} for p in m['source_before']}
m['source_unchanged_after_build']=m['source_before']==m['source_after_build']
m['project_objects']={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.glob('*/*.o'))}
m['executables']={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.glob('*/*-asan-ubsan'))}
path.write_text(json.dumps(m,indent=2)+'\n')
print('Build complete; source unchanged='+str(m['source_unchanged_after_build']),flush=True)

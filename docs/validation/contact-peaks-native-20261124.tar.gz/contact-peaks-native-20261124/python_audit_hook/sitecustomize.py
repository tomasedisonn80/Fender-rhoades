"""Temporary Python-level evidence guard; not an OS process-tree tracer."""
import json, os, sys, time
log=os.environ['CONTACT_PEAK_AUDIT_LOG']
allowed=os.path.realpath(sys.executable)
def emit(record):
    record.update(pid=os.getpid(),time_ns=time.time_ns())
    descriptor=os.open(log,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
    try: os.write(descriptor,(json.dumps(record,sort_keys=True)+'\n').encode())
    finally: os.close(descriptor)
def hook(event,args):
    if event in ('subprocess.Popen','os.exec','os.posix_spawn'):
        executable=os.fsdecode(args[0])
        permit=os.path.realpath(executable)==allowed
        emit({'event':event,'executable':executable,'argv':args[1], 'guard_allows':permit})
        if not permit: raise PermissionError('Evidence guard permits only the current Python interpreter')
    elif event=='os.system':
        emit({'event':event,'guard_allows':False})
        raise PermissionError('Evidence guard refuses shell launch')
    elif event=='cpython.run_file':
        emit({'event':event,'file':os.fsdecode(args[0])})
sys.addaudithook(hook)
emit({'event':'python_audit_guard_started','executable':sys.executable,'argv':sys.argv,'only_allowed_executable':allowed})

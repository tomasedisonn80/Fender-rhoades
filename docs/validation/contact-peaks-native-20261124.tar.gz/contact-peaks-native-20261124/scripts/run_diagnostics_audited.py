from pathlib import Path
import hashlib, importlib.metadata, json, os, subprocess, sys, time
from datetime import datetime, timezone
root=Path(__file__).resolve().parents[1]
plan=json.loads((root/'plan.json').read_text())
repo=Path(plan['repository']); binary=repo/plan['binary']
def now(): return datetime.now(timezone.utc).isoformat()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def sources(): return {p:sha(repo/p) for p in plan['sources']}
def write(path,data):
    with path.open('x') as handle: json.dump(data,handle,sort_keys=True,indent=2,allow_nan=False); handle.write('\n')
try: scipy_version=importlib.metadata.version('scipy')
except importlib.metadata.PackageNotFoundError: scipy_version=None
phase={'phase':'python_diagnostic_audited','started_utc':now(),'argv':sys.argv,'source_sha256_before':sources(),'binary_sha256_before':sha(binary),'scipy_version':scipy_version,'native_binary_execution_allowed':False,'own_python_scipy_worker_allowed':True,'candidate_production_attested':False,'phy002_acceptance':'incomplete','invocations':[]}
(root/'cli-audited').mkdir()
write(root/'cli-audited-phase-start.json',phase)
sets=[('all_four_default',['conservative_impact','damped_impact','forced_clamp','preload_equilibrium'],False,0,[0,0,0,0]),('damped_with_time',['damped_impact'],True,0 if scipy_version else 2,[0 if scipy_version else 2]),('partial_missing_unsupported',['conservative_partial_failure','conservative_no_peaks','evolved_relaunch_unsupported'],False,1,[1,2,2])]
for name,case_ids,damped,expected,individual in sets:
    out=root/'cli-audited'/name; out.mkdir(); evidence=out/'evidence'
    argv=[sys.executable,str(repo/'tools/validate_contact_peaks.py'),'--output',str(evidence),'--producer-binary',str(binary)]
    for case in case_ids: argv.extend(['--candidate',str(root/'native'/case/'stdout.json')])
    if damped: argv.append('--with-damped-time')
    trace=out/'python-process-audit.jsonl'
    env=dict(os.environ)
    env['PYTHONPATH']=str(root/'python_audit_hook')+os.pathsep+env.get('PYTHONPATH','')
    env['CONTACT_PEAK_AUDIT_LOG']=str(trace)
    record={'id':name,'argv':argv,'audit_hook_source':'python_audit_hook/sitecustomize.py','audit_scope':'Python-level observation and guard, inherited by the SciPy worker through PYTHONPATH; not OS process-tree tracing','cwd':str(repo),'started_utc':now(),'timeout_s':plan['cli_timeout_s'],'source_sha256_before':sources(),'binary_sha256_before':sha(binary),'expected_returncode':expected,'expected_case_exit_codes':individual,'output_did_not_exist_before':not evidence.exists()}
    start=time.monotonic()
    try:
        process=subprocess.run(argv,cwd=repo,env=env,capture_output=True,check=False,timeout=plan['cli_timeout_s'])
        stdout,stderr=process.stdout,process.stderr
        record.update(returncode=process.returncode,timed_out=False)
    except subprocess.TimeoutExpired as error:
        stdout,stderr=error.stdout or b'',error.stderr or b''
        record.update(returncode=None,timed_out=True)
    record.update(elapsed_s=time.monotonic()-start,ended_utc=now(),source_sha256_after=sources(),binary_sha256_after=sha(binary))
    for suffix,data in [('stdout.txt',stdout),('stderr.txt',stderr)]:
        with (out/suffix).open('xb') as handle: handle.write(data)
    record['source_unchanged']=record['source_sha256_before']==record['source_sha256_after']
    record['binary_unchanged']=record['binary_sha256_before']==record['binary_sha256_after']
    audit=[json.loads(line) for line in trace.read_text().splitlines()] if trace.exists() else []
    observed=[event for event in audit if event.get('executable')]
    record['python_audit_events']=audit
    record['audit_sha256']=sha(trace) if trace.exists() else None
    record['diagnostic_executed_declared_binary']=any(Path(event['executable']).resolve()==binary.resolve() and event.get('guard_allows',True) for event in observed)
    record['observed_executables_are_python']=bool(observed) and all(Path(event['executable']).resolve()==Path(sys.executable).resolve() for event in observed)
    record['audit_hook_loaded_in_interpreters']=sum(event['event']=='python_audit_guard_started' for event in audit)
    record['rejected_process_requests']=[event for event in audit if event.get('guard_allows') is False]
    manifest_path=evidence/'manifest.json'
    if manifest_path.exists():
        manifest=json.loads(manifest_path.read_bytes())
        record.update(manifest_file=str(manifest_path.relative_to(root)),manifest_sha256=sha(manifest_path),manifest_exit_code=manifest.get('exit_code'),case_exit_codes=[case['exit_code'] for case in manifest['cases']],declared_producer=manifest.get('declared_producer'),diagnostic_internal_source_unchanged=manifest.get('source_unchanged'),cases=[])
        for native_id,case in zip(case_ids,manifest['cases']):
            result={'native_id':native_id,'fixture':case.get('fixture'),'status':case['status'],'exit_code':case['exit_code'],'availability':case.get('availability'),'raw_sha256':case.get('raw_sha256'),'retained_sha256':case.get('retained_sha256'),'comparison_file':case.get('comparison_file')}
            if case.get('comparison_file'):
                comparison=json.loads((evidence/case['comparison_file']).read_bytes())
                result.update(validity=comparison['validity'],phy002_acceptance=comparison['phy002_acceptance'],peaks={})
                for peak,details in comparison['peaks'].items():
                    result['peaks'][peak]={'value_status':details['value_status'],'time_status':details['time_status'],'observation_consistency_status':details['observation_consistency_status'],'time_comparison_required':details['time_comparison_required'],'exit_code':details['exit_code'],'candidate':details['candidate'],'reference_kind':details['reference']['kind'],'reference_value_interval':details['reference']['value_interval'],'reference_time_intervals_s':details['reference']['maximizer_intervals_s'],'reference_value_status':details['reference']['value_status'],'reference_time_status':details['reference']['time_status'],'coverage':details['coverage']}
            record['cases'].append(result)
    record['expected_outcome_observed']=record.get('returncode')==expected and record.get('case_exit_codes')==individual
    write(out/'invocation.json',record); phase['invocations'].append(record)
    print(json.dumps({'phase':'diagnostic','id':name,'returncode':record['returncode'],'expected_returncode':expected,'cases':record.get('case_exit_codes'),'expected_outcome_observed':record['expected_outcome_observed'],'source_unchanged':record['source_unchanged'],'observed_executables':[event['executable'] for event in observed],'diagnostic_executed_declared_binary':record['diagnostic_executed_declared_binary']},sort_keys=True),flush=True)
phase.update(ended_utc=now(),source_sha256_after=sources(),binary_sha256_after=sha(binary))
phase['source_unchanged']=phase['source_sha256_before']==phase['source_sha256_after']
phase['binary_unchanged']=phase['binary_sha256_before']==phase['binary_sha256_after']
write(root/'cli-audited-phase.json',phase)

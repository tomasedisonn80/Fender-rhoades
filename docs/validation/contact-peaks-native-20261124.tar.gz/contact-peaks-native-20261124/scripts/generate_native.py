from pathlib import Path
import hashlib, json, platform, subprocess, sys, time
from datetime import datetime, timezone
root=Path(__file__).resolve().parents[1]
plan=json.loads((root/'plan.json').read_text())
repo=Path(plan['repository'])
binary=repo/plan['binary']
def now(): return datetime.now(timezone.utc).isoformat()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def sources(): return {p:sha(repo/p) for p in plan['sources']}
def write(path,data):
    with path.open('x') as handle: json.dump(data,handle,sort_keys=True,indent=2,allow_nan=False); handle.write('\n')
phase={'phase':'native_fixture_generation','started_utc':now(),'argv':sys.argv,'python':sys.version,'platform':platform.platform(),'source_sha256_before':sources(),'binary':{'path':str(binary),'bytes':binary.stat().st_size,'sha256_before':sha(binary)},'cases':[],'candidate_production_attested':False,'phy002_acceptance':'incomplete'}
(root/'native').mkdir()
(root/'source_snapshot').mkdir()
for name in plan['sources']:
    path=root/'source_snapshot'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as handle: handle.write((repo/name).read_bytes())
write(root/'native-phase-start.json',phase)
for case in plan['native_cases']:
    out=root/'native'/case['id']; out.mkdir()
    argv=[str(binary),'--fixture',case['fixture'],'--output-step',plan['output_step']]
    if case.get('maximum_step'): argv.extend(['--max-step',case['maximum_step']])
    if case['peak_option']: argv.append('--locate-peak-candidates')
    record={'id':case['id'],'argv':argv,'cwd':str(repo),'started_utc':now(),'timeout_s':plan['native_timeout_s'],'binary_sha256_before':sha(binary)}
    start=time.monotonic()
    try:
        process=subprocess.run(argv,cwd=repo,capture_output=True,check=False,timeout=plan['native_timeout_s'])
        stdout,stderr=process.stdout,process.stderr
        record.update(returncode=process.returncode,timed_out=False)
    except subprocess.TimeoutExpired as error:
        stdout,stderr=error.stdout or b'',error.stderr or b''
        record.update(returncode=None,timed_out=True)
    record.update(elapsed_s=time.monotonic()-start,ended_utc=now(),binary_sha256_after=sha(binary))
    with (out/'stdout.json').open('xb') as handle: handle.write(stdout)
    with (out/'stderr.txt').open('xb') as handle: handle.write(stderr)
    record.update(stdout_file=str((out/'stdout.json').relative_to(root)),stdout_bytes=len(stdout),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_file=str((out/'stderr.txt').relative_to(root)),stderr_bytes=len(stderr),stderr_sha256=hashlib.sha256(stderr).hexdigest())
    try:
        run=json.loads(stdout)['runs'][0]
        record['native_result']={'fixture':run['fixture'],'success':run['success'],'failure_code':run['failure_code'],'samples':len(run['samples']),'last_sample_time_s':run['samples'][-1]['time_s'],'has_located_peak_candidates':'located_peak_candidates' in run['diagnostics']}
    except (ValueError,KeyError,IndexError,TypeError) as error: record['inspection_error']=str(error)
    write(out/'invocation.json',record); phase['cases'].append(record)
    print(json.dumps({'phase':'native','case':case['id'],'returncode':record['returncode'],'bytes':len(stdout),'result':record.get('native_result'),'inspection_error':record.get('inspection_error')},sort_keys=True),flush=True)
phase.update(source_sha256_after=sources(),ended_utc=now())
phase['binary']['sha256_after']=sha(binary)
phase['source_unchanged']=phase['source_sha256_before']==phase['source_sha256_after']
phase['binary_unchanged']=phase['binary']['sha256_before']==phase['binary']['sha256_after']
write(root/'native-phase.json',phase)

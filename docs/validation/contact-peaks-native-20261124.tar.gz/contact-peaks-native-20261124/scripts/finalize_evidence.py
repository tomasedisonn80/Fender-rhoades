from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip, hashlib, json, tarfile

root=Path(__file__).resolve().parents[1]
plan=json.loads((root/'plan.json').read_bytes())
repo=Path(plan['repository'])
archive=repo/'docs/validation/contact-peaks-native-20261124.tar.gz'
summary_path=repo/'docs/validation/contact-peaks-native-20261124.json'
report_path=repo/'docs/agents/reports/20261124-w2-27-native.md'
for path in (archive,summary_path,report_path):
    if path.exists(): raise SystemExit('Refusing existing assigned artifact: '+str(path))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):
    with path.open('x') as handle:
        json.dump(data,handle,sort_keys=True,indent=2,allow_nan=False)
        handle.write('\n')
native=json.loads((root/'native-phase.json').read_bytes())
cli=json.loads((root/'cli-audited-phase.json').read_bytes())
tracing=json.loads((root/'cli-phase.json').read_bytes())
expected_native={case['id']:(2 if case['id']=='conservative_partial_failure' else 0) for case in plan['native_cases']}
checks=[]
for case in native['cases']:
    checks.append(case['returncode']==expected_native[case['id']] and not case['timed_out'])
    checks.append(sha(root/case['stdout_file'])==case['stdout_sha256'])
    checks.append(case['binary_sha256_before']==case['binary_sha256_after']==native['binary']['sha256_before'])
all_source=native['source_sha256_before']
checks.extend([native['source_sha256_after']==all_source,cli['source_sha256_before']==all_source,cli['source_sha256_after']==all_source])
for source,digest in all_source.items():
    checks.extend([sha(repo/source)==digest,sha(root/'source_snapshot'/source)==digest])
raw_matches=[]
for invocation in cli['invocations']:
    checks.extend([invocation['expected_outcome_observed'],invocation['source_unchanged'],invocation['diagnostic_internal_source_unchanged'],invocation['binary_unchanged'],invocation['source_sha256_before']==all_source,invocation['source_sha256_after']==all_source,invocation['observed_executables_are_python'],not invocation['diagnostic_executed_declared_binary'],not invocation['rejected_process_requests'],invocation['output_did_not_exist_before']])
    checks.extend([invocation['declared_producer']['sha256']==native['binary']['sha256_before'],invocation['declared_producer']['executed'] is False,invocation['declared_producer']['candidate_production_attested'] is False])
    manifest_file=root/invocation['manifest_file']
    manifest=json.loads(manifest_file.read_bytes())
    for original,case in zip(invocation['cases'],manifest['cases']):
        retained=manifest_file.parent/case['raw_file']
        native_file=root/'native'/original['native_id']/'stdout.json'
        match=retained.read_bytes()==native_file.read_bytes()
        checks.append(match)
        raw_matches.append({'invocation':invocation['id'],'native_case':original['native_id'],'retained_file':str(retained.relative_to(root)),'sha256':sha(retained),'exact_native_stdout_bytes':match})
if not all(checks): raise SystemExit('Evidence verification failed; no final artifact written')

native_summary=[]
for case in native['cases']:
    native_summary.append({key:case[key] for key in ('id','argv','cwd','returncode','elapsed_s','started_utc','ended_utc','stdout_file','stdout_bytes','stdout_sha256','stderr_file','stderr_bytes','stderr_sha256','native_result')})
invocations=[]
for run in cli['invocations']:
    invocations.append({key:run[key] for key in ('id','argv','cwd','returncode','expected_returncode','expected_case_exit_codes','case_exit_codes','expected_outcome_observed','elapsed_s','started_utc','ended_utc','source_unchanged','diagnostic_internal_source_unchanged','binary_unchanged','manifest_file','manifest_sha256','declared_producer','audit_hook_source','audit_scope','audit_sha256','audit_hook_loaded_in_interpreters','rejected_process_requests','observed_executables_are_python','diagnostic_executed_declared_binary','cases')})
summary={
 'schema_version':1,'assignment':'20261124-w2-27-native','scope':'Actual existing native producer generated seven synthetic fixture inputs; separate Python diagnostic completed exactly three requested invocation groups.',
 'outcome':'expected_focused_outcomes_observed','phy002_acceptance':'incomplete','candidate_production_attested':False,
 'started_utc':native['started_utc'],'ended_utc':cli['ended_utc'],
 'native_producer':native['binary'],'source_sha256_before':all_source,'source_sha256_after':cli['source_sha256_after'],'source_unchanged':True,
 'versions':{'python':native['python'],'platform':native['platform'],'scipy':cli['scipy_version']},
 'native_generation':native_summary,'diagnostic_invocations':invocations,'retained_raw_identity_checks':raw_matches,
 'failed_process_trace_attempts':{'reason':'Kernel denied ptrace: Operation not permitted. These instrumentation attempts did not execute the Python CLI or create its evidence output.','attempts':[{'id':i['id'],'instrumented_argv':i['instrumented_argv'],'returncode':i['returncode'],'observed_execve':i['observed_execve'],'source_unchanged':i['source_unchanged'],'stderr_file':'cli/'+i['id']+'/stderr.txt','invocation_file':'cli/'+i['id']+'/invocation.json'} for i in tracing['invocations']]},
 'process_observation':{'mechanism':'Temporary sitecustomize Python audit hook, inherited through PYTHONPATH by the optional timing worker. Logs Python interpreter starts and audited subprocess/exec calls; rejects child executables other than the same Python interpreter.','scope':'Python-level observation and guard only; not OS process-tree tracing or cryptographic attestation.','native_fixture_generation_was_separate':True,'declared_native_binary_execution_observed_in_diagnostic':False,'optional_python_timing_worker_observed':True},
 'verification':{'expected_cli_exit_codes':[0,0,1],'observed_cli_exit_codes':[i['returncode'] for i in cli['invocations']],'expected_mixed_case_exit_codes':[1,2,2],'observed_mixed_case_exit_codes':cli['invocations'][2]['case_exit_codes'],'all_checks_satisfied':True,'raw_retention_identity_checks':len(raw_matches),'all_raw_retention_identity_checks_pass':all(x['exact_native_stdout_bytes'] for x in raw_matches)},
 'limitations':[
  'Only these named synthetic fixtures are covered. No hardware fidelity, calibrated specimen behavior, or general continuous-extrema acceptance is established.',
  'The default all-four invocation passes values and available analytic timing. Damped hammer timing is unrequested/not_available there; a separate flagged invocation resolves it under the declared SciPy refinement.',
  'Preload positive damper timing remains unresolved_near_equilibrium even when its verified value enclosures pass; the result is not a positive plateau claim.',
  'Candidate sign-change peak coverage remains uncertified. Supplemental timing does not amend frozen acceptance.',
  'Declared producer identity is a stable file hash only. The native envelope does not attest arbitrary candidate physical configuration, and hashing is not execution attestation.',
  'Kernel ptrace restrictions prevented OS process-tree tracing; every failed attempt and the subsequent Python audit evidence are retained.',
  'The no-SciPy branch was not exercised in this native evidence run because SciPy 1.17.0 was available.',
  'No source edits, build, Git operations, canonical state edits, old-auditor command, or whole test suite was performed by this assignment.']}
write(root/'summary-core.json',summary)
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
artifact_manifest={'schema_version':1,'archive_root':'contact-peaks-native-20261124','files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
write(root/'artifact-manifest.json',artifact_manifest)
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as bundle:
            for path in files:
                if path.is_symlink(): raise RuntimeError('Unexpected symlink')
                name='contact-peaks-native-20261124/'+str(path.relative_to(root))
                if PurePosixPath(name).is_absolute() or '..' in PurePosixPath(name).parts: raise RuntimeError('Unsafe archive member')
                bundle.add(path,arcname=name,recursive=False)
verified=[]
with tarfile.open(archive,'r:gz') as bundle:
    members=bundle.getmembers()
    if len(members)!=len(files): raise RuntimeError('Archive member count mismatch')
    for member in members:
        if not member.isfile() or member.issym() or member.islnk() or PurePosixPath(member.name).is_absolute() or '..' in PurePosixPath(member.name).parts:
            raise RuntimeError('Unsafe archive member')
        relative=PurePosixPath(member.name).relative_to('contact-peaks-native-20261124')
        data=bundle.extractfile(member).read()
        if hashlib.sha256(data).hexdigest()!=sha(root/str(relative)): raise RuntimeError('Archived bytes changed')
        verified.append(str(relative))
summary['archive']={'path':'docs/validation/'+archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(files),'uncompressed_file_bytes':sum(p.stat().st_size for p in files),'member_names_relative_and_safe':True,'all_member_bytes_verified':True,'artifact_manifest':'contact-peaks-native-20261124/artifact-manifest.json'}
write(summary_path,summary)

binary_hash=native['binary']['sha256_before']
source_rows='\n'.join('| `'+name+'` | `'+digest+'` |' for name,digest in all_source.items())
native_rows='\n'.join('| `'+case['id']+'` | '+str(case['returncode'])+' | '+str(case['native_result']['success']).lower()+' / '+str(case['native_result']['failure_code'])+' | '+str(case['native_result']['samples'])+' | `'+case['stdout_sha256']+'` |' for case in native['cases'])
report=f'''# Wave 2 / assignment 27 — retained native contact peak evidence

## Outcome and boundary

The requested bounded native-to-diagnostic exercise produced the expected outcomes:
all four supported fixtures returned Python CLI **0**, requested damped timing
with available **SciPy {cli['scipy_version']}** returned **0**, and the mixed
failure/missing/unsupported collection returned **1**, preserving per-case
**1 / 2 / 2**. These are observations about the seven named synthetic inputs
retained below. **PHY-002 remains incomplete.** No specimen, calibration,
hardware fidelity, or general continuous-extrema acceptance is claimed.

The evidence was captured from `{native['started_utc']}` through
`{cli['ended_utc']}` using the existing built
`build/vst3/rhodes_contact_reference`; this worker did not build or change it.
The report filename is the assigned campaign label; execution timestamps are
retained exactly as reported by the environment clock.

## Owned artifacts

- [Compact result and identities](../../validation/{summary_path.name})
- [Original evidence archive](../../validation/{archive.name})
- This immutable assignment report.

The archive contains **{len(files)} regular files**, including seven exact native
stdout inputs, their stderr and invocation records, all eight CLI-retained input
copies, original plans/manifests/comparisons/references, Python audit events,
source snapshots, the collection scripts, and all failed tracing attempts. Its
members use relative names under `contact-peaks-native-20261124/`; every archived
member was reread and matched against its original SHA-256. There are no symlink,
hard-link, absolute, or `..` members. Large temporary evidence directories were
kept outside the repository.

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| `{archive.name}` | {archive.stat().st_size} | `{sha(archive)}` |
| `{summary_path.name}` | {summary_path.stat().st_size} | `{sha(summary_path)}` |
| Declared native executable | {native['binary']['bytes']} | `{binary_hash}` |

## Exact native generation

For every case the producer argv began with the absolute executable path,
`--fixture NAME --output-step 0.0001`, with options and values as separate argv
tokens. The first four, partial-failure case, and unsupported case appended
`--locate-peak-candidates`. Only the partial-failure case added
`--max-step 1e-10`; the missing-diagnostic case omitted the peak option.
Every original argv, working directory, return code, stdout/stderr hash,
byte count, and start/end time is retained in `native/*/invocation.json` and the
compact JSON. Each generation had a 30-second timeout and completed within it.

| Native case | Process exit | Native success / failure code | Exported samples | Raw stdout SHA-256 |
| --- | ---: | --- | ---: | --- |
{native_rows}

The intentional conservative partial failure returned native process **2** and
`failure_code: 9` (`evaluation_limit`), retaining a valid one-sample initial
trajectory. It is diagnosed as `producer_failure`, not successful comparison.
All native stderr files were empty. The unsupported `evolved_relaunch` input was
produced normally and retained its action snapshot; its valid native execution
does not bring it into the four-fixture analytic scope.

## Separate Python diagnostic executions

Native generation finished before any successful Python diagnostic invocation.
Each invocation used the actual `tools/validate_contact_peaks.py` CLI with
repeatable `--candidate` paths, `--producer-binary` set to the declared native
file, and a distinct nonexistent `--output` directory. The optional timing case
added `--with-damped-time`. Exact argv and all output artifacts are archived in
`cli-audited/*/`; each CLI had a 40-second collection timeout. The CLI's own
bounded timing worker retains its tighter contract limits and refinements.

| Invocation | Expected / observed exit | Preserved individual exits | Observation |
| --- | --- | --- | --- |
| Four supported fixtures, default options | 0 / 0 | 0, 0, 0, 0 | All 16 values and their observation-consistency checks pass. |
| `damped_impact`, requested damped time | 0 / 0 | 0 | Both distinct hammer maximizing times pass under SciPy refinement. |
| Partial failure, omitted peaks, unsupported fixture | 1 / 1 | 1, 2, 2 | Definite producer failure outranks incomplete missing/unsupported evidence. |

The mixed collection retained respectively `validity=producer_failure`,
`availability=not_available`, and `availability=unsupported_fixture`; none was
silently discarded. All three successful CLI executions had empty stderr and
`source_unchanged=true`. All **eight retained raw inputs** match their original
native stdout bytes exactly.

## Value results remain separate from timing

| Fixture / invocation | Value results | Timing results | Semantics preserved |
| --- | --- | --- | --- |
| `conservative_impact`, default | Four pass | Four pass | Two isolated hammer maxima and two disabled damper records. |
| `damped_impact`, default | Four pass | Two hammer `not_available`; two disabled damper pass | Unrequested damped timing does not prevent value-only completion. |
| `forced_clamp`, default | Four pass | Four pass | Initial compression maximum; enabled zero-force hammer plateau over the full duration; damper disabled. |
| `preload_equilibrium`, default | Four pass | Hammer zero plateaus pass; both positive damper times `unresolved_near_equilibrium` | Positive damper values use verified enclosures and are not exact positive plateaus. |
| `damped_impact`, requested timing | Four pass | Four pass | Refined compression and force times are distinct; quadrature estimates are not certificates. |

For requested damped timing, the native compression maximum occurs at
`0.00034506005488022017 s` versus reference
`0.00034505973795999833 s`, and the native force maximum occurs at
`0.0001776913414242453 s` versus reference
`0.00017769056225746204 s`. The force maximum precedes the compression maximum.
Both pass their supplemental timing budgets. Complete candidate brackets,
independent intervals, value/time budgets, errors, coverage, and refinement
records are retained in the original comparison/reference files.

Preload damper compression is enclosed by
`[1.0320962512323202e-05, 1.0320962512323224e-05] m`, and damper force by
`[0.12385155014787841, 0.12385155014787869] N`. Passing those value comparisons does
not resolve either positive maximizing time. Candidate sign-change coverage and
full continuous-extrema acceptance remain incomplete.

## Process observation and its precise limits

An initial attempt to use `/usr/bin/strace` for each of the three CLI groups
failed before CLI execution because the environment rejected `ptrace` with
`Operation not permitted`. All three stderr files, empty traces, argv, and return
codes **1** remain archived under `cli/`. No diagnostic output directory was
created by those attempts; they are recorded as failed instrumentation, not
passing CLI evidence. No privilege escalation or altered permission was used.

The subsequent fresh invocations used a temporary stdlib `sitecustomize` audit
hook outside the repository. It records Python interpreter starts and audited
subprocess/exec requests, and permits child execution only of the same Python
interpreter. The requested SciPy run inherited the hook through `PYTHONPATH`;
its audit file contains two interpreter-start records, one for the CLI and one
for its timing worker, and the permitted Python subprocess request. The other
two runs each contain one interpreter-start record. No child request was rejected
and no native-producer launch was observed in these Python diagnostic runs.
This is **Python-level observation and guard**, not OS process-tree tracing.

Native generation is a separate observed collection phase. Every diagnostic
manifest states `declared_producer.executed=false` and
`candidate_production_attested=false`. A stable file hash and this capture do
not attest arbitrary candidate physical configuration or constitute a
cryptographic execution attestation.

## Source and binary identities

The following source hashes were identical before/after native generation,
before/after every successful diagnostic invocation, across those phases, and
at packaging. Original source snapshots are retained in the archive. Each CLI
also retains its own six-file `source_sha256_before` and `source_sha256_after`.
The native binary hash above was unchanged before/after each generation and
all successful diagnostic invocations.

| Source | SHA-256 before = after |
| --- | --- |
{source_rows}

## Commands, limitations, and handoff

The retained collection commands were:

```text
python3 /tmp/contact-peaks-native-20261124-a3kcslzv/scripts/generate_native.py
python3 /tmp/contact-peaks-native-20261124-a3kcslzv/scripts/run_diagnostics.py
python3 /tmp/contact-peaks-native-20261124-a3kcslzv/scripts/run_diagnostics_audited.py
python3 /tmp/contact-peaks-native-20261124-a3kcslzv/scripts/finalize_evidence.py
```

The first created the seven native inputs. The second retained the three failed
ptrace launch attempts. The third ran the actual focused CLI checks. The fourth
performed artifact identity/archive checks and produced this report, summary,
and archive. Exact nested argv are in the retained records, so the wrapper
commands do not substitute for producer or CLI invocation evidence.

The no-SciPy timing branch was not exercised here because SciPy 1.17.0 was
available. No build, general audit, existing whole test suite, source edit,
Git operation, canonical state update, or solver change was performed by this
assignment. The evidence supports only these synthetic fixture checks.
The integrator should review/register these immutable artifacts and preserve
PHY-002's incomplete continuous-extrema gate.
'''
with report_path.open('x') as handle: handle.write(report)
print(json.dumps({'summary':str(summary_path.relative_to(repo)),'summary_sha256':sha(summary_path),'archive':str(archive.relative_to(repo)),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'archive_files':len(files),'report':str(report_path.relative_to(repo)),'report_sha256':sha(report_path),'expected_cli_outcomes_observed':True,'phy002_acceptance':'incomplete'},sort_keys=True))

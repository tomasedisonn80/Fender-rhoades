import sys, subprocess, json, pathlib, hashlib, time
root=pathlib.Path('/workspace/scratch/68ec02e60e7e/Fender-rhoades')
work=pathlib.Path('/dev/shm/rhodes-d-w041')
shared=pathlib.Path('/tmp/rhodes-d-build')
variant=sys.argv[1]
lane=work/variant
lane.mkdir(exist_ok=True)
flags=['-O3','-DNDEBUG','-std=gnu++20','-Wall','-Wextra','-Wpedantic','-Wconversion','-Wshadow','-Werror','-DRELEASE=1','-I'+str(root),'-I'+str(root/'include'),'-isystem','/workspace/scratch/d6370337c6a4/vst3sdk']
if variant!='direct': flags += ['-DRHODES_'+variant.upper()+'_VST3=1']
sources=['tests/cpp/vst3_expression_fault_test.cpp','plugins/vst3/processor.cpp','plugins/vst3/controller.cpp','plugins/vst3/state_stream.cpp']
commands=[]
objects=[]
for i,src in enumerate(sources):
    obj=lane/(str(i)+'.o')
    objects.append(str(obj))
    commands.append(['/usr/bin/c++',*flags,'-c',str(root/src),'-o',str(obj)])
commands.append(['/usr/bin/c++','-O3','-DNDEBUG',*objects,'-Wl,--wrap=_ZN6rhodes14ResearchEngine7processESt4spanIdLm18446744073709551615EE','-Wl,--wrap=_ZNK6rhodes14ResearchEngine12observe_cellERKNS_25FractionalObservationPlanE',str(shared/'librhodes_core.a'),*[str(shared/'lib/Release'/x) for x in ['libsdk.a','libsdk_common.a','libbase.a','libpluginterfaces.a']],'-lstdc++fs','-lpthread','-ldl','-o',str(lane/'fault_tests')])
record={'variant':variant,'sources':{src:hashlib.sha256((root/src).read_bytes()).hexdigest() for src in sources},'commands':[]}
with (lane/'build.log').open('w') as log:
    for command in commands:
        start=time.time()
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        record['commands'].append({'argv':command,'exit':result.returncode,'seconds':time.time()-start})
        if result.returncode: break
(lane/'build.json').write_text(json.dumps(record,indent=2)+'\n')
print(variant, 'exit', result.returncode)
if result.returncode: print((lane/'build.log').read_text())
sys.exit(result.returncode)

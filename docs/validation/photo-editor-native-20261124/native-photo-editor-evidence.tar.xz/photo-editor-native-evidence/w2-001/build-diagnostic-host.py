#!/usr/bin/env python3
"""Rebuild only the pinned SDK editorhost TU with accepting/logged edit callbacks."""
from pathlib import Path
import difflib
import hashlib
import json
import shlex
import subprocess

TASK = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
BUILD = TASK / "host-build"
SDK_SOURCE = TASK / "vst3sdk/public.sdk/samples/vst-hosting/editorhost/source/editorhost.cpp"
original = SDK_SOURCE.read_text()
changed = original
for method, statement in (
    ("beginEdit", '\t\tstd::cout << "beginEdit called (" << id << ")" << std::endl;'),
    ("performEdit", '\t\tstd::cout << "performEdit called (" << id << ", " << valueNormalized << ")" << std::endl;'),
    ("endEdit", '\t\tstd::cout << "endEdit called (" << id << ")" << std::endl;'),
):
    start = changed.index("\ttresult PLUGIN_API " + method + " (")
    end = changed.index("\n\t}", start)
    body = changed[start:end]
    lines = body.splitlines()
    assert len(lines) == 4 and "SMTG_DBPRT" in lines[2] and "return kNotImplemented;" in lines[3]
    lines[2] = statement
    lines[3] = "\t\treturn kResultOk;"
    changed = changed[:start] + "\n".join(lines) + changed[end:]
local_source = OUT / "editorhost-accepting.cpp"
local_source.write_text(changed)
(OUT / "editorhost-accepting.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(keepends=True), changed.splitlines(keepends=True),
    fromfile=str(SDK_SOURCE), tofile=str(local_source))))
commands = subprocess.check_output(["ninja", "-t", "commands", "editorhost"], cwd=BUILD, text=True).splitlines()
compile_line = next(line for line in commands if line.endswith("-c " + str(SDK_SOURCE)))
link_line = next(line for line in commands if " -o bin/Release/editorhost " in line)
compile_args = shlex.split(compile_line)
object_path = OUT / "editorhost-accepting.cpp.o"
for option, value in (("-MT", str(object_path)), ("-MF", str(object_path) + ".d"),
                      ("-o", str(object_path)), ("-c", str(local_source))):
    compile_args[compile_args.index(option) + 1] = value
assert link_line.startswith(": && ") and link_line.endswith(" && :")
link_args = shlex.split(link_line[5:-5])
for i, arg in enumerate(link_args):
    if arg.endswith("/source/editorhost.cpp.o"):
        link_args[i] = str(object_path)
    if arg.startswith("-Wl,--dependency-file="):
        link_args[i] = "-Wl,--dependency-file=" + str(OUT / "editorhost-accepting.link.d")
link_args[link_args.index("-o") + 1] = str(OUT / "editorhost-accepting")
(OUT / "commands.json").write_text(json.dumps({"cwd": str(BUILD), "compile": compile_args, "link": link_args}, indent=2) + "\n")
for command in (compile_args, link_args):
    subprocess.run(command, cwd=BUILD, check=True)
records = []
for path in (SDK_SOURCE, local_source, OUT / "editorhost-accepting.diff", OUT / "editorhost-accepting", BUILD / "bin/Release/editorhost"):
    records.append({"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size})
(OUT / "provenance.json").write_text(json.dumps({"boundary": "The copied SDK host accepts and logs only beginEdit, performEdit and endEdit. It does not process audio. Original SDK/host-build files are unchanged.", "files": records}, indent=2) + "\n")
print(json.dumps(records, indent=2))

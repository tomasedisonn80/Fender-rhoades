export RHODES_TASK_ROOT=/home/agent/rhodes-7a7c13ab7da3
export PYTHONPATH="$RHODES_TASK_ROOT/build-tools${PYTHONPATH:+:$PYTHONPATH}"
export PATH="$RHODES_TASK_ROOT/build-tools/cmake/data/bin:$RHODES_TASK_ROOT/build-tools/bin:$PATH"

#!/usr/bin/env python3
"""Run one command under task-local, cookie-authenticated TCP Xvfb."""
from pathlib import Path
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent

def main():
    command = sys.argv[1:]
    if command[:1] == ['--']:
        command.pop(0)
    if not command:
        print('usage: with-xvfb.py [--] command [args...]', file=sys.stderr)
        return 2
    with tempfile.TemporaryDirectory(prefix='xvfb-', dir=ROOT) as temporary:
        authority = Path(temporary) / 'authority'
        authority.touch(mode=0o600)
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', 0))
            display = probe.getsockname()[1] - 6000
        if display <= 0:
            raise RuntimeError('Allocated port is outside the X11 display range')
        display_name = f'127.0.0.1:{display}'
        subprocess.run(['xauth', '-f', str(authority), 'add', display_name,
                        'MIT-MAGIC-COOKIE-1', secrets.token_hex(16)],
                       check=True, stdout=subprocess.DEVNULL)
        environment = os.environ.copy()
        environment.update(DISPLAY=display_name, XAUTHORITY=str(authority))
        log_path = ROOT / 'apt/logs' / f'xvfb-{os.getpid()}.log'
        with log_path.open('w') as output:
            server = subprocess.Popen(
                [str(ROOT / 'sysroot/usr/bin/Xvfb'), f':{display}',
                 '-screen', '0', '1280x900x24', '-nolisten', 'local',
                 '-nolisten', 'unix', '-listen', 'tcp', '-auth',
                 str(authority), '-noreset'], stdout=output,
                stderr=subprocess.STDOUT)
            try:
                for attempt in range(50):
                    if server.poll() is not None:
                        raise RuntimeError(f'Xvfb exited; see {log_path}')
                    result = subprocess.run(['xdpyinfo'], env=environment,
                                            stdout=subprocess.DEVNULL,
                                            stderr=subprocess.DEVNULL)
                    if result.returncode == 0:
                        break
                    time.sleep(0.1)
                else:
                    raise RuntimeError(f'Xvfb not ready; see {log_path}')
                return subprocess.run(command, env=environment).returncode
            finally:
                if server.poll() is None:
                    server.terminate()
                    try:
                        server.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait()

if __name__ == '__main__':
    raise SystemExit(main())

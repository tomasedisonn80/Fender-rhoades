# W1-005 task-local native Linux GUI development overlay.
export RHODES_GUI_ROOT=/home/agent/rhodes-7a7c13ab7da3
export RHODES_GUI_SYSROOT="$RHODES_GUI_ROOT/sysroot"
export PATH="$RHODES_GUI_SYSROOT/usr/bin:$PATH"
export PKG_CONFIG_PATH="$RHODES_GUI_SYSROOT/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
export CMAKE_PREFIX_PATH="$RHODES_GUI_SYSROOT/usr${CMAKE_PREFIX_PATH:+:$CMAKE_PREFIX_PATH}"
export CMAKE_LIBRARY_PATH="$RHODES_GUI_SYSROOT/usr/lib/x86_64-linux-gnu${CMAKE_LIBRARY_PATH:+:$CMAKE_LIBRARY_PATH}"
export LIBRARY_PATH="$RHODES_GUI_SYSROOT/usr/lib/x86_64-linux-gnu${LIBRARY_PATH:+:$LIBRARY_PATH}"
export LD_LIBRARY_PATH="$RHODES_GUI_SYSROOT/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
# No PKG_CONFIG_SYSROOT_DIR: verified existing system runtime libraries are used.
# GUI CMake also needs:
# -DWAYLAND_PROTOCOLS_BASEDIR=$RHODES_GUI_SYSROOT/usr/share/wayland-protocols

#!/usr/bin/env python3
"""Supplement the unchanged native harness with held-motion focus regressions."""
import importlib.util
from pathlib import Path

REPO = Path('/workspace/scratch/7a7c13ab7da3/Fender-rhoades')
spec = importlib.util.spec_from_file_location('native_photo', REPO / 'tools/verify_native_photo_editor.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)


def begin_held_drag(self):
    self.pointer(native.VOLUME)
    self.button(True)
    self.pointer((native.VOLUME[0], native.VOLUME[1] - 18))


def loss_then_motion(self, restore_before_motion=False):
    begin_held_drag(self)
    start = len(self.events)
    self.focus_target.set_input_focus(self.X.RevertToPointerRoot, self.X.CurrentTime)
    if restore_before_motion:
        self.view.set_input_focus(self.X.RevertToParent, self.X.CurrentTime)
    self.connection.sync()
    self.pointer((native.VOLUME[0], native.VOLUME[1] - 36))
    self.pause(0.2)
    selected = [event for event in self.events[start:] if event['parameter_id'] == 0]
    ended = sum(event['kind'] == 'endEdit' for event in selected)
    edited = [event for event in selected if event['kind'] == 'performEdit']
    label = 'quick_focus_out_back' if restore_before_motion else 'external_focus_loss'
    self.check(label + '_ends_once_before_release', 'pass' if ended == 1 else 'fail', events=selected)
    self.check(label + '_held_motion_does_not_edit', 'pass' if not edited else 'fail', events=edited)

    self.view.set_input_focus(self.X.RevertToParent, self.X.CurrentTime)
    self.connection.sync()
    returned_start = len(self.events)
    self.pointer((native.VOLUME[0], native.VOLUME[1] - 54))
    self.pause(0.1)
    returned = [event for event in self.events[returned_start:] if event['parameter_id'] == 0]
    self.check(label + '_refocus_without_new_press_does_not_resume',
               'pass' if not returned else 'fail', events=returned)
    self.capture(label + '-after-held-motion')
    self.button(False)


def descendant_motion(self):
    begin_held_drag(self)
    child = self.view.create_window(0, 0, 20, 20, 0, self.X.CopyFromParent,
                                    self.X.InputOutput, self.X.CopyFromParent)
    try:
        child.map()
        child.set_input_focus(self.X.RevertToParent, self.X.CurrentTime)
        start = len(self.events)
        self.connection.sync()
        self.pointer((native.VOLUME[0], native.VOLUME[1] - 36))
        self.pause(0.2)
        events = [event for event in self.events[start:] if event['parameter_id'] == 0]
        edited = [event for event in events if event['kind'] == 'performEdit']
        self.check('native_descendant_focus_keeps_existing_drag',
                   'pass' if edited and not any(event['kind'] == 'endEdit' for event in events)
                   else 'fail', events=events)
        self.button(False)
    finally:
        child.destroy()
        self.connection.sync()


def run(self):
    self.launch()
    with self.Image.open(self.args.reference) as reference:
        self.reference = reference.convert('RGB')
    self.resize()
    comparison = native.image_metrics(self.capture('idle-before-focus-motion'), self.reference)
    self.check('initial_full_photo_exact', 'pass' if comparison['exact'] else 'fail', comparison=comparison)
    self.action('external_focus_loss_motion', lambda: loss_then_motion(self), 0, 0.6)
    self.action('reset_after_external_loss', self.reset_volume, 0, 0.5)
    self.action('quick_focus_out_back_motion', lambda: loss_then_motion(self, True), 0, 0.6)
    self.action('reset_after_quick_return', self.reset_volume, 0, 0.5)
    self.action('native_descendant_focus_motion', lambda: descendant_motion(self), 0, 0.7)
    self.action('reset_after_descendant', self.reset_volume, 0, 0.5)
    self.outside()
    self.pause(0.3)
    comparison = native.image_metrics(self.capture('idle-after-focus-motion'), self.reference)
    self.check('final_full_photo_exact', 'pass' if comparison['exact'] else 'fail', comparison=comparison)
    self.close_during_drag()


native.NativeRun.run = run
raise SystemExit(native.main())

#include "plugins/vst3/photo_native_focus.hpp"

#include <xcb/xcb.h>
#include <cstdlib>
#include <iostream>
#include <stdexcept>

using rhodes::vst3::PhotoNativeFocus;

namespace {
void check(bool success, const char* name) {
    std::cout << (success ? "PASS " : "FAIL ") << name << std::endl;
    if (!success) { throw std::runtime_error(name); }
}

void synchronize(xcb_connection_t* connection) {
    auto* reply = xcb_get_input_focus_reply(connection, xcb_get_input_focus(connection), nullptr);
    if (reply == nullptr) { throw std::runtime_error("X11 synchronization failed"); }
    std::free(reply);
}

void focus(xcb_connection_t* connection, xcb_window_t window) {
    xcb_set_input_focus(connection, XCB_INPUT_FOCUS_PARENT, window, XCB_CURRENT_TIME);
    synchronize(connection);
}

xcb_window_t window(xcb_connection_t* connection, xcb_window_t parent) {
    const auto id = xcb_generate_id(connection);
    const std::uint32_t mask = XCB_EVENT_MASK_FOCUS_CHANGE;
    xcb_create_window(connection, XCB_COPY_FROM_PARENT, id, parent,
                      0, 0, 100, 100, 0, XCB_WINDOW_CLASS_INPUT_OUTPUT,
                      XCB_COPY_FROM_PARENT, XCB_CW_EVENT_MASK, &mask);
    xcb_map_window(connection, id);
    synchronize(connection);
    return id;
}

void grab(xcb_connection_t* connection, xcb_window_t popup) {
    auto* reply = xcb_grab_keyboard_reply(connection,
        xcb_grab_keyboard(connection, false, popup, XCB_CURRENT_TIME,
                          XCB_GRAB_MODE_ASYNC, XCB_GRAB_MODE_ASYNC), nullptr);
    const bool success = reply != nullptr && reply->status == XCB_GRAB_STATUS_SUCCESS;
    std::free(reply);
    if (!success) { throw std::runtime_error("X11 keyboard grab failed"); }
}
}

int main() {
    auto* connection = xcb_connect(nullptr, nullptr);
    if (connection == nullptr || xcb_connection_has_error(connection) != 0) { return 2; }
    try {
        const auto root = xcb_setup_roots_iterator(xcb_get_setup(connection)).data->root;
        const auto editor = window(connection, root);
        const auto child = window(connection, editor);
        const auto sibling = window(connection, root);
        const auto popup = window(connection, root);
        focus(connection, editor);
        PhotoNativeFocus observer;
        observer.attach(editor);
        check(!observer.poll(true), "initial focused editor has no loss");

        focus(connection, child);
        check(!observer.poll(true), "focus to native descendant is preserved");
        focus(connection, editor);
        check(!observer.poll(true), "focus from descendant back to editor is preserved");
        focus(connection, child);
        check(!observer.poll(true), "second native descendant focus is preserved");
        focus(connection, sibling);
        check(observer.poll(true), "focus from descendant to sibling cancels");
        check(!observer.poll(true), "loss is consumed once");

        focus(connection, editor);
        check(!observer.poll(true), "focus gain alone does not cancel");
        focus(connection, sibling);
        focus(connection, editor);
        check(observer.poll(true), "out and back before polling retains loss");

        grab(connection, popup);
        check(!observer.poll(true), "popup keyboard grab alone does not cancel");
        xcb_ungrab_keyboard(connection, XCB_CURRENT_TIME);
        synchronize(connection);
        check(!observer.poll(true), "popup keyboard ungrab alone does not cancel");

        grab(connection, popup);
        check(!observer.poll(true), "second popup grab alone does not cancel");
        focus(connection, sibling);
        check(observer.poll(true), "actual focus loss while keyboard grabbed cancels");
        xcb_ungrab_keyboard(connection, XCB_CURRENT_TIME);
        synchronize(connection);
        (void)observer.poll(true);

        PhotoNativeFocus second;
        second.attach(sibling);
        focus(connection, editor);
        (void)observer.poll(true);
        (void)second.poll(true);
        focus(connection, sibling);
        check(observer.poll(true) && !second.poll(true), "two observers preserve independent focus ownership");
        focus(connection, editor);
        check(!observer.poll(true) && second.poll(true), "opposite editor transition cancels only losing observer");

        while (auto* event = xcb_poll_for_event(connection)) { std::free(event); }
        focus(connection, sibling);
        check(observer.poll(true), "independent observer receives raw loss");
        bool original_received_loss = false;
        while (auto* event = xcb_poll_for_event(connection)) {
            if ((event->response_type & 0x7fU) == XCB_FOCUS_OUT &&
                reinterpret_cast<xcb_focus_out_event_t*>(event)->event == editor) {
                original_received_loss = true;
            }
            std::free(event);
        }
        check(original_received_loss, "original client event queue and subscription are preserved");

        focus(connection, editor);
        (void)observer.poll(true);
        for (unsigned index = 0; index < 70; ++index) {
            xcb_set_input_focus(connection, XCB_INPUT_FOCUS_PARENT,
                                index % 2 ? editor : sibling, XCB_CURRENT_TIME);
        }
        synchronize(connection);
        check(observer.poll(true), "bounded focus-event burst cancels conservatively");

        observer.reset();
        check(!observer.poll(true), "removed observer has no live connection");
        observer.attach(xcb_generate_id(connection));
        check(!observer.poll(true), "invalid native window degrades without termination");
        observer.reset();
        observer.attach(editor);
        (void)observer.poll(true);
        focus(connection, sibling);
        check(observer.poll(true), "reattachment restores native monitoring");
        observer.reset();
        second.reset();
        xcb_disconnect(connection);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << std::endl;
        xcb_disconnect(connection);
        return 1;
    }
}
